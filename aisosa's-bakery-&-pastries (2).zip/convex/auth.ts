import { convexAuth } from "@convex-dev/auth/server";
import { Password } from "@convex-dev/auth/providers/Password";
import { getAuthUserId } from "@convex-dev/auth/server";
import { QueryCtx, MutationCtx } from "./_generated/server";

export const { auth, signIn, signOut, store, isAuthenticated } = convexAuth({
  providers: [
    Password({
      profile(params: Record<string, any>) {
        // Disable public sign-up and password reset:
        // throw an error unless params.flow === "signIn"
        if (params.flow !== "signIn") {
          throw new Error("Registration is disabled. Only the designated administrator may sign in.");
        }

        const adminEmail = process.env.ADMIN_EMAIL;
        if (!adminEmail || !adminEmail.trim()) {
          throw new Error("Admin email is not configured on the server.");
        }

        const candidateEmail = (params.email as string)?.trim().toLowerCase();
        if (candidateEmail !== adminEmail.trim().toLowerCase()) {
          throw new Error("Access denied.");
        }

        return {
          email: candidateEmail,
        };
      },
    }),
  ],
});

/**
 * Strict server-side verification that caller is authenticated and matches ADMIN_EMAIL.
 * Fails closed: if ADMIN_EMAIL is not set, nobody is admin.
 * Compares emails case-insensitively.
 */
export async function assertAdmin(ctx: QueryCtx | MutationCtx) {
  const configuredAdmin = process.env.ADMIN_EMAIL;
  if (!configuredAdmin || !configuredAdmin.trim()) {
    throw new Error("Forbidden: Administrator email is not configured.");
  }

  const userId = await getAuthUserId(ctx);
  if (!userId) {
    throw new Error("Unauthenticated: Admin privileges required.");
  }

  const user = await ctx.db.get(userId);
  if (!user || !("email" in user) || !user.email) {
    throw new Error("Forbidden: Invalid user credentials.");
  }

  if (
    (user.email as string).trim().toLowerCase() !==
    configuredAdmin.trim().toLowerCase()
  ) {
    throw new Error("Forbidden: This account does not possess administrator rights.");
  }

  return { userId, user };
}
