import { defineSchema, defineTable } from "convex/server";
import { authTables } from "@convex-dev/auth/server";
import { v } from "convex/values";

export default defineSchema({
  ...authTables,

  categories: defineTable({
    name: v.string(),
    slug: v.string(),
    sortOrder: v.number(),
  }).index("by_sortOrder", ["sortOrder"]),

  products: defineTable({
    name: v.string(),
    description: v.string(),
    price: v.number(), // In Nigerian Naira (₦)
    categoryId: v.id("categories"),
    imageStorageId: v.optional(v.id("_storage")),
    imageUrl: v.optional(v.string()), // Direct URL or pre-seeded image
    isAvailable: v.boolean(),
    isFeatured: v.boolean(),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_category", ["categoryId"])
    .index("by_featured", ["isFeatured"])
    .index("by_availability", ["isAvailable"])
    .index("by_created", ["createdAt"]),
});
