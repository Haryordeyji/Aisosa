import { AnyApi } from "convex/server";
export declare const api: AnyApi;
export declare const internal: AnyApi;
