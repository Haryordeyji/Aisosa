import { v } from "convex/values";
import { mutation, query, QueryCtx, MutationCtx } from "./_generated/server";
import { assertAdmin } from "./auth";

/**
 * Public query: Fetch all publicly available products for customers.
 * Resolves image storage URLs automatically.
 */
export const listPublic = query({
  args: {
    categoryId: v.optional(v.id("categories")),
    showUnavailable: v.optional(v.boolean()),
  },
  handler: async (ctx: QueryCtx, args: { categoryId?: any; showUnavailable?: boolean }) => {
    let productsQuery = ctx.db.query("products");

    let products: any[];
    if (args.categoryId) {
      const catId = args.categoryId;
      products = await productsQuery
        .withIndex("by_category", (q: any) => q.eq("categoryId", catId))
        .collect();
    } else {
      products = await productsQuery.order("desc").collect();
    }

    if (!args.showUnavailable) {
      products = products.filter((p) => p.isAvailable);
    }

    // Resolve storage URLs and category names
    const categories = await ctx.db.query("categories").collect();
    const categoryMap = new Map(categories.map((c: any) => [c._id, c.name]));

    return await Promise.all(
      products.map(async (product) => {
        let resolvedImageUrl = product.imageUrl || null;
        if (product.imageStorageId) {
          const storageUrl = await ctx.storage.getUrl(product.imageStorageId);
          if (storageUrl) {
            resolvedImageUrl = storageUrl;
          }
        }

        return {
          _id: product._id,
          name: product.name,
          description: product.description,
          price: product.price,
          categoryId: product.categoryId,
          categoryName: categoryMap.get(product.categoryId) || "Uncategorized",
          imageUrl: resolvedImageUrl,
          isAvailable: product.isAvailable,
          isFeatured: product.isFeatured,
          createdAt: product.createdAt,
        };
      })
    );
  },
});

/**
 * Public query: Fetch featured products for the storefront hero & showcase.
 */
export const listFeatured = query({
  args: {},
  handler: async (ctx: QueryCtx) => {
    const products = await ctx.db
      .query("products")
      .withIndex("by_featured", (q: any) => q.eq("isFeatured", true))
      .filter((q: any) => q.eq(q.field("isAvailable"), true))
      .take(6);

    const categories = await ctx.db.query("categories").collect();
    const categoryMap = new Map(categories.map((c: any) => [c._id, c.name]));

    return await Promise.all(
      products.map(async (product: any) => {
        let resolvedImageUrl = product.imageUrl || null;
        if (product.imageStorageId) {
          const storageUrl = await ctx.storage.getUrl(product.imageStorageId);
          if (storageUrl) {
            resolvedImageUrl = storageUrl;
          }
        }

        return {
          _id: product._id,
          name: product.name,
          description: product.description,
          price: product.price,
          categoryId: product.categoryId,
          categoryName: categoryMap.get(product.categoryId) || "Specialty",
          imageUrl: resolvedImageUrl,
          isAvailable: product.isAvailable,
          isFeatured: product.isFeatured,
          createdAt: product.createdAt,
        };
      })
    );
  },
});

/**
 * Admin query: Fetch all products with full schema details.
 */
export const listAdmin = query({
  args: {},
  handler: async (ctx: QueryCtx) => {
    await assertAdmin(ctx);

    const products = await ctx.db.query("products").order("desc").collect();
    const categories = await ctx.db.query("categories").collect();
    const categoryMap = new Map(categories.map((c: any) => [c._id, c.name]));

    return await Promise.all(
      products.map(async (p: any) => {
        let resolvedImageUrl = p.imageUrl || null;
        if (p.imageStorageId) {
          const storageUrl = await ctx.storage.getUrl(p.imageStorageId);
          if (storageUrl) {
            resolvedImageUrl = storageUrl;
          }
        }
        return {
          ...p,
          categoryName: categoryMap.get(p.categoryId) || "Uncategorized",
          imageUrl: resolvedImageUrl,
        };
      })
    );
  },
});

/**
 * Admin mutation: Generate an authorized file upload URL for Convex file storage.
 */
export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx: MutationCtx) => {
    await assertAdmin(ctx);
    return await ctx.storage.generateUploadUrl();
  },
});

/**
 * Admin mutation: Create a new product.
 */
export const createProduct = mutation({
  args: {
    name: v.string(),
    description: v.string(),
    price: v.number(),
    categoryId: v.id("categories"),
    imageStorageId: v.optional(v.id("_storage")),
    imageUrl: v.optional(v.string()),
    isAvailable: v.boolean(),
    isFeatured: v.boolean(),
  },
  handler: async (
    ctx: MutationCtx,
    args: {
      name: string;
      description: string;
      price: number;
      categoryId: any;
      imageStorageId?: any;
      imageUrl?: string;
      isAvailable: boolean;
      isFeatured: boolean;
    }
  ) => {
    await assertAdmin(ctx);

    if (args.price <= 0) {
      throw new Error("Price must be a positive amount in Nigerian Naira.");
    }
    if (!args.name.trim()) {
      throw new Error("Product name is required.");
    }

    return await ctx.db.insert("products", {
      name: args.name.trim(),
      description: args.description.trim(),
      price: Math.round(args.price),
      categoryId: args.categoryId,
      imageStorageId: args.imageStorageId,
      imageUrl: args.imageUrl,
      isAvailable: args.isAvailable,
      isFeatured: args.isFeatured,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });
  },
});

/**
 * Admin mutation: Update an existing product.
 */
export const updateProduct = mutation({
  args: {
    id: v.id("products"),
    name: v.string(),
    description: v.string(),
    price: v.number(),
    categoryId: v.id("categories"),
    imageStorageId: v.optional(v.id("_storage")),
    imageUrl: v.optional(v.string()),
    isAvailable: v.boolean(),
    isFeatured: v.boolean(),
  },
  handler: async (
    ctx: MutationCtx,
    args: {
      id: any;
      name: string;
      description: string;
      price: number;
      categoryId: any;
      imageStorageId?: any;
      imageUrl?: string;
      isAvailable: boolean;
      isFeatured: boolean;
    }
  ) => {
    await assertAdmin(ctx);

    const existing = await ctx.db.get(args.id);
    if (!existing) {
      throw new Error("Product not found.");
    }

    if (
      args.imageStorageId &&
      existing.imageStorageId &&
      args.imageStorageId !== existing.imageStorageId
    ) {
      try {
        await ctx.storage.delete(existing.imageStorageId);
      } catch (err) {
        console.error("Failed to delete superseded storage file:", err);
      }
    }

    await ctx.db.patch(args.id, {
      name: args.name.trim(),
      description: args.description.trim(),
      price: Math.round(args.price),
      categoryId: args.categoryId,
      imageStorageId: args.imageStorageId ?? existing.imageStorageId,
      imageUrl: args.imageUrl ?? existing.imageUrl,
      isAvailable: args.isAvailable,
      isFeatured: args.isFeatured,
      updatedAt: Date.now(),
    });
  },
});

/**
 * Admin mutation: Quick inline price update directly from the dashboard list.
 */
export const quickUpdatePrice = mutation({
  args: {
    id: v.id("products"),
    price: v.number(),
  },
  handler: async (ctx: MutationCtx, args: { id: any; price: number }) => {
    await assertAdmin(ctx);

    if (args.price <= 0) {
      throw new Error("Price must be greater than zero.");
    }

    await ctx.db.patch(args.id, {
      price: Math.round(args.price),
      updatedAt: Date.now(),
    });
  },
});

/**
 * Admin mutation: Delete a product and its associated storage file.
 */
export const deleteProduct = mutation({
  args: {
    id: v.id("products"),
  },
  handler: async (ctx: MutationCtx, args: { id: any }) => {
    await assertAdmin(ctx);

    const product = await ctx.db.get(args.id);
    if (!product) {
      throw new Error("Product not found.");
    }

    if (product.imageStorageId) {
      try {
        await ctx.storage.delete(product.imageStorageId);
      } catch (err) {
        console.error("Failed to clean up storage image:", err);
      }
    }

    await ctx.db.delete(args.id);
  },
});

/**
 * Admin mutation: Seed initial sample bakery products.
 */
export const seedSampleProducts = mutation({
  args: {},
  handler: async (ctx: MutationCtx) => {
    await assertAdmin(ctx);

    let cakesCat = await ctx.db
      .query("categories")
      .filter((q: any) => q.eq(q.field("name"), "Celebration Cakes"))
      .first();
    if (!cakesCat) {
      const cakesId = await ctx.db.insert("categories", {
        name: "Celebration Cakes",
        slug: "celebration-cakes",
        sortOrder: 0,
      });
      cakesCat = await ctx.db.get(cakesId);
    }

    let pastriesCat = await ctx.db
      .query("categories")
      .filter((q: any) => q.eq(q.field("name"), "Artisan Pastries"))
      .first();
    if (!pastriesCat) {
      const pastriesId = await ctx.db.insert("categories", {
        name: "Artisan Pastries",
        slug: "artisan-pastries",
        sortOrder: 1,
      });
      pastriesCat = await ctx.db.get(pastriesId);
    }

    let savoryCat = await ctx.db
      .query("categories")
      .filter((q: any) => q.eq(q.field("name"), "Savory Delights"))
      .first();
    if (!savoryCat) {
      const savoryId = await ctx.db.insert("categories", {
        name: "Savory Delights",
        slug: "savory-delights",
        sortOrder: 2,
      });
      savoryCat = await ctx.db.get(savoryId);
    }

    const sampleProducts = [
      {
        name: "Vanilla Celebration Cake",
        description:
          "Three layers of tender vanilla sponge with silky Swiss meringue buttercream and fresh florals. Made for weddings, milestone birthdays, and family celebrations.",
        price: 35000,
        categoryId: cakesCat!._id,
        imageUrl:
          "https://images.unsplash.com/photo-1565958011703-44f9829ba187?auto=format&fit=crop&w=1000&q=80",
        isAvailable: true,
        isFeatured: true,
      },
      {
        name: "Dark Chocolate Ganache Cake",
        description:
          "Deep cocoa sponge filled and frosted with smooth Belgian chocolate ganache and delicate chocolate shavings. Baked fresh to order.",
        price: 38000,
        categoryId: cakesCat!._id,
        imageUrl:
          "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=1000&q=80",
        isAvailable: true,
        isFeatured: true,
      },
      {
        name: "Classic Red Velvet Cake",
        description:
          "Traditional velvet crumb layered with real vanilla cream cheese frosting. An enduring centerpiece for birthdays and special gatherings.",
        price: 32000,
        categoryId: cakesCat!._id,
        imageUrl:
          "https://images.unsplash.com/photo-1586788680434-30d324b2d46f?auto=format&fit=crop&w=1000&q=80",
        isAvailable: true,
        isFeatured: true,
      },
      {
        name: "Flaky Nigerian Meat Pie",
        description:
          "Golden, buttery pastry filled with well-seasoned minced beef, diced potatoes, and carrots. Freshly baked each morning.",
        price: 2500,
        categoryId: savoryCat!._id,
        imageUrl:
          "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=1000&q=80",
        isAvailable: true,
        isFeatured: true,
      },
      {
        name: "Morning Cinnamon Brioche Rolls",
        description:
          "Soft butter brioche rolled with cinnamon sugar and topped with a light cream cheese glaze. Pack of 4.",
        price: 4500,
        categoryId: pastriesCat!._id,
        imageUrl:
          "https://images.unsplash.com/photo-1509365465985-25d11c17e812?auto=format&fit=crop&w=1000&q=80",
        isAvailable: true,
        isFeatured: false,
      },
      {
        name: "Vanilla Glazed Ring Doughnuts",
        description:
          "Golden, slow-fermented brioche doughnuts finished with a delicate vanilla bean glaze. Box of 4.",
        price: 6000,
        categoryId: pastriesCat!._id,
        imageUrl:
          "https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=1000&q=80",
        isAvailable: true,
        isFeatured: false,
      },
    ];

    for (const prod of sampleProducts) {
      const exists = await ctx.db
        .query("products")
        .filter((q: any) => q.eq(q.field("name"), prod.name))
        .first();

      if (!exists) {
        await ctx.db.insert("products", {
          ...prod,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        });
      }
    }

    return { success: true, message: "Sample products seeded successfully." };
  },
});
