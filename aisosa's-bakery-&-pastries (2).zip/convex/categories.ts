import { v } from "convex/values";
import { mutation, query, QueryCtx, MutationCtx } from "./_generated/server";
import { assertAdmin } from "./auth";

/**
 * Public query: Fetch all bakery categories in display order.
 */
export const list = query({
  args: {},
  handler: async (ctx: QueryCtx) => {
    return await ctx.db
      .query("categories")
      .withIndex("by_sortOrder")
      .collect();
  },
});

/**
 * Admin mutation: Create a new category.
 */
export const create = mutation({
  args: {
    name: v.string(),
    sortOrder: v.optional(v.number()),
  },
  handler: async (ctx: MutationCtx, args: { name: string; sortOrder?: number }) => {
    await assertAdmin(ctx);

    const name = args.name.trim();
    if (!name) {
      throw new Error("Category name cannot be empty.");
    }

    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-");
    const count = (await ctx.db.query("categories").collect()).length;

    return await ctx.db.insert("categories", {
      name,
      slug,
      sortOrder: args.sortOrder ?? count,
    });
  },
});

/**
 * Admin mutation: Rename or update sort order.
 */
export const update = mutation({
  args: {
    id: v.id("categories"),
    name: v.string(),
    sortOrder: v.optional(v.number()),
  },
  handler: async (ctx: MutationCtx, args: { id: any; name: string; sortOrder?: number }) => {
    await assertAdmin(ctx);

    const name = args.name.trim();
    if (!name) {
      throw new Error("Category name cannot be empty.");
    }

    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-");
    const patch: { name: string; slug: string; sortOrder?: number } = { name, slug };
    if (args.sortOrder !== undefined) {
      patch.sortOrder = args.sortOrder;
    }

    await ctx.db.patch(args.id, patch);
  },
});

/**
 * Admin mutation: Delete a category (checks for active products).
 */
export const remove = mutation({
  args: {
    id: v.id("categories"),
  },
  handler: async (ctx: MutationCtx, args: { id: any }) => {
    await assertAdmin(ctx);

    // Check if products exist in this category
    const linkedProducts = await ctx.db
      .query("products")
      .withIndex("by_category", (q: any) => q.eq("categoryId", args.id))
      .first();

    if (linkedProducts) {
      throw new Error("Cannot delete category with associated products. Reassign or delete products first.");
    }

    await ctx.db.delete(args.id);
  },
});
