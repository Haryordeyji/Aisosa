import { query, internalAction, QueryCtx, ActionCtx } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { createAccount, modifyAccountCredentials } from "@convex-dev/auth/server";

/**
 * Public query admin.isAdmin
 * Returns true only if the signed-in user's email equals ADMIN_EMAIL (case-insensitively).
 * Returns false for everyone else and when unauthenticated; never throws.
 */
export const isAdmin = query({
  args: {},
  handler: async (ctx: QueryCtx) => {
    const configuredAdmin = process.env.ADMIN_EMAIL;
    if (!configuredAdmin || !configuredAdmin.trim()) {
      return false;
    }

    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return false;
    }

    const user = await ctx.db.get(userId);
    if (!user || !("email" in user) || !user.email) {
      return false;
    }

    return (
      (user.email as string).trim().toLowerCase() ===
      configuredAdmin.trim().toLowerCase()
    );
  },
});

/**
 * Internal action admin.setupAdmin
 * Reads ADMIN_EMAIL and ADMIN_PASSWORD from Convex environment variables.
 * Creates the password account using createAccount from "@convex-dev/auth/server",
 * or resets it with modifyAccountCredentials if it already exists.
 * Returns a message.
 * Run once via terminal: `npx convex run admin:setupAdmin`
 */
export const setupAdmin = internalAction({
  args: {},
  handler: async (ctx: ActionCtx) => {
    const email = process.env.ADMIN_EMAIL?.trim();
    const password = process.env.ADMIN_PASSWORD;

    if (!email) {
      throw new Error(
        "ADMIN_EMAIL environment variable is missing in Convex. Please set it in your Convex dashboard or via `npx convex env set ADMIN_EMAIL <email>`."
      );
    }
    if (!password || password.length < 8) {
      throw new Error(
        "ADMIN_PASSWORD environment variable is missing or shorter than 8 characters. Please set it in Convex via `npx convex env set ADMIN_PASSWORD <password>`."
      );
    }

    const cleanEmail = email.toLowerCase();

    try {
      // Attempt to create the initial admin account
      await createAccount(ctx, {
        provider: "password",
        account: {
          id: cleanEmail,
          secret: password,
        },
        profile: {
          email: cleanEmail,
          name: "Bakery Administrator",
        },
      });
      return `Admin account successfully created for: ${cleanEmail}`;
    } catch (err: any) {
      // If the account already exists, modify the existing credentials
      try {
        await modifyAccountCredentials(ctx, {
          provider: "password",
          account: {
            id: cleanEmail,
            secret: password,
          },
        });
        return `Existing admin account credentials updated for: ${cleanEmail}`;
      } catch (modifyErr: any) {
        throw new Error(
          `Failed to create or update admin account: ${err?.message || err} | ${modifyErr?.message || modifyErr}`
        );
      }
    }
  },
});
