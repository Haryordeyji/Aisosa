'use client';

import React from 'react';
import { Navbar } from '@/components/Navbar';
import { MenuCatalog } from '@/components/MenuCatalog';
import { Footer } from '@/components/Footer';
import { FloatingContactButtons } from '@/components/FloatingContactButtons';

export default function MenuPage() {
  return (
    <div className="min-h-screen flex flex-col bg-[#FAF6F0]">
      <Navbar />
      <main className="flex-1">
        <MenuCatalog />
      </main>
      <Footer />
      <FloatingContactButtons />
    </div>
  );
}
