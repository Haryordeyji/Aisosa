import type { Metadata } from 'next';
import { Montserrat, Open_Sans, Dancing_Script } from 'next/font/google';
import './globals.css';
import { ConvexClientProvider } from '@/components/ConvexClientProvider';
import { ToastContainer } from '@/components/Toasts';
import { BAKERY_CONFIG } from '@/src/config';

const montserrat = Montserrat({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-heading',
  weight: ['600', '700', '800'],
});

const openSans = Open_Sans({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-body',
  weight: ['400', '500', '600', '700'],
});

const dancingScript = Dancing_Script({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-brand',
  weight: ['700'],
});

export const metadata: Metadata = {
  title: `${BAKERY_CONFIG.brandName} | Cakes & Pastries`,
  description: BAKERY_CONFIG.description,
  openGraph: {
    title: `${BAKERY_CONFIG.brandName} | Cakes & Pastries`,
    description: BAKERY_CONFIG.description,
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: `${BAKERY_CONFIG.brandName} | Cakes & Pastries`,
    description: BAKERY_CONFIG.description,
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${montserrat.variable} ${openSans.variable} ${dancingScript.variable}`}>
      <body className="bg-[#FAF6F0] text-[#3B2418] font-sans antialiased min-h-screen selection:bg-[#B8913B]/20 selection:text-[#3B2418]" suppressHydrationWarning>
        <ConvexClientProvider>
          {children}
          <ToastContainer />
        </ConvexClientProvider>
      </body>
    </html>
  );
}
