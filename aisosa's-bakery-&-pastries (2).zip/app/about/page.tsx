'use client';

import React from 'react';
import Link from 'next/link';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { FloatingContactButtons } from '@/components/FloatingContactButtons';
import { getWhatsAppLink } from '@/src/config';
import { ArrowRight } from 'lucide-react';

function WhatsAppIcon({ className = 'w-4 h-4' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.472 14.382c-.301-.15-1.781-.878-2.056-.978-.276-.1-.476-.15-.676.15-.2.301-.776.978-.951 1.178-.175.201-.351.226-.652.076-.301-.15-1.272-.469-2.424-1.496-.896-.799-1.5-1.788-1.676-2.088-.176-.301-.019-.464.132-.614.136-.135.301-.351.451-.527.15-.175.2-.3.301-.501.1-.201.05-.376-.025-.526-.075-.15-.677-1.631-.927-2.233-.243-.586-.49-.506-.676-.516l-.576-.01c-.2 0-.526.075-.802.376-.275.301-1.052 1.028-1.052 2.508 0 1.48 1.077 2.909 1.227 3.109.15.201 2.12 3.238 5.137 4.542.717.31 1.277.496 1.713.635.72.23 1.375.197 1.892.12.576-.086 1.781-.728 2.032-1.431.25-.702.25-1.304.175-1.43-.075-.126-.275-.201-.576-.351zM12.04 2C6.516 2 2.025 6.49 2.025 12.015c0 1.956.564 3.784 1.542 5.334L2 22.025l4.825-1.523c1.487.917 3.23 1.442 5.215 1.442 5.525 0 10.015-4.49 10.015-10.015C22.055 6.49 17.565 2 12.04 2z" />
    </svg>
  );
}

export default function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col bg-[#FAF6F0]">
      <Navbar />

      <main className="flex-1 pt-24 pb-16 sm:pt-28 sm:pb-20">
        <div className="max-w-[820px] mx-auto px-6 sm:px-8">
          <span className="text-[14px] sm:text-[15px] font-semibold text-[#B8913B] mb-2 block">
            About our bakery
          </span>
          <h1 className="font-heading text-4xl sm:text-5xl font-bold text-[#3B2418] leading-tight">
            About Aisosa&apos;s Bakery
          </h1>

          <div className="mt-8 space-y-5 text-[17px] lg:text-[18px] text-[#6B4A3A] leading-relaxed">
            <p>
              We bake cakes and pastries for birthdays, weddings and everyday treats. Our menu shows every price so you can easily see what we offer and plan your event without guessing.
            </p>
            <p>
              Orders are not taken directly on this website. Please message us on WhatsApp or call to ask what is available for your date, check delivery options, or discuss what kind of cake you would like.
            </p>
          </div>

          <div className="mt-12 p-8 sm:p-10 bg-white rounded-2xl border border-[#3B2418]/10 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-6">
            <div>
              <span className="text-[14px] font-semibold text-[#B8913B] block mb-1">
                Direct orders
              </span>
              <h2 className="font-heading text-2xl font-bold text-[#3B2418]">
                Ready to order or have a question?
              </h2>
              <p className="text-[15px] text-[#6B4A3A] mt-1">
                We are always happy to help you with your order.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto shrink-0">
              <a
                href={getWhatsAppLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-[#B8913B] hover:bg-[#a68030] text-white text-[15px] font-bold rounded-md shadow-xs hover:shadow-sm hover:-translate-y-0.5 transition-all w-full sm:w-auto"
              >
                <WhatsAppIcon className="w-4 h-4 fill-current shrink-0" />
                <span>Chat on WhatsApp</span>
              </a>
              <Link
                href="/menu"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-transparent hover:bg-[#FAF6F0] text-[#3B2418] text-[15px] font-bold rounded-md border border-[#3B2418]/25 hover:border-[#3B2418] transition-all w-full sm:w-auto"
              >
                <span>View menu</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </main>

      <Footer />
      <FloatingContactButtons />
    </div>
  );
}
