'use client';

import React from 'react';
import { Navbar } from '@/components/Navbar';
import { Hero } from '@/components/Hero';
import { FeaturedProducts } from '@/components/FeaturedProducts';
import { AboutSection } from '@/components/AboutSection';
import { GalleryStrip } from '@/components/GalleryStrip';
import { ContactSection } from '@/components/ContactSection';
import { Footer } from '@/components/Footer';
import { FloatingContactButtons } from '@/components/FloatingContactButtons';

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col bg-[#FAF6F0]">
      <Navbar />
      <main className="flex-1">
        <Hero />
        <FeaturedProducts />
        <AboutSection />
        <GalleryStrip />
        <ContactSection />
      </main>
      <Footer />
      <FloatingContactButtons />
    </div>
  );
}
