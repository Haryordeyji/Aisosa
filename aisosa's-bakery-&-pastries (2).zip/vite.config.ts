import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  const rootDir = import.meta.dirname || process.cwd();
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: [
        { find: 'next/link', replacement: path.resolve(rootDir, 'src/shims/next-link.tsx') },
        { find: 'next/image', replacement: path.resolve(rootDir, 'src/shims/next-image.tsx') },
        { find: 'next/navigation', replacement: path.resolve(rootDir, 'src/shims/next-navigation.tsx') },
        { find: 'next/font/google', replacement: path.resolve(rootDir, 'src/shims/next-font-google.ts') },
        { find: /^next$/, replacement: path.resolve(rootDir, 'src/shims/next.ts') },
        { find: '@', replacement: path.resolve(rootDir, '.') },
      ],
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
