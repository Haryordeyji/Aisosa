'use client';

import React, { createContext, useContext, useMemo, useState } from 'react';
import { useQuery, useMutation } from 'convex/react';
import { useAuthActions } from '@convex-dev/auth/react';
import { api } from '@/convex/_generated/api';

export interface Category {
  _id: string;
  name: string;
  slug: string;
  sortOrder: number;
}

export interface Product {
  _id: string;
  name: string;
  description: string;
  price: number;
  categoryId: string;
  categoryName?: string;
  imageUrl?: string | null;
  imageStorageId?: string;
  isAvailable: boolean;
  isFeatured: boolean;
  createdAt: number;
  updatedAt?: number;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface BakeryStoreContextType {
  // Data
  categories: Category[];
  products: Product[];
  publicProducts: Product[];
  featuredProducts: Product[];
  isLoading: boolean;
  isConvexConnected: boolean;

  // Filters
  selectedCategory: string;
  setSelectedCategory: (catId: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  showUnavailable: boolean;
  setShowUnavailable: (val: boolean) => void;

  // Admin Auth
  isAuthenticated: boolean;
  isAuthLoading: boolean;
  login: (email: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;

  // Admin CRUD operations
  addProduct: (product: {
    name: string;
    description: string;
    price: number;
    categoryId: string;
    imageUrl?: string | null;
    imageStorageId?: string;
    isAvailable: boolean;
    isFeatured: boolean;
  }) => Promise<any>;
  updateProduct: (id: string, updates: Partial<Product>) => Promise<void>;
  quickUpdatePrice: (id: string, newPrice: number) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  addCategory: (name: string) => Promise<any>;
  updateCategory: (id: string, name: string) => Promise<void>;
  deleteCategory: (id: string) => Promise<void>;
  seedSampleProducts: () => Promise<void>;
  generateUploadUrl: () => Promise<string>;

  // Toasts
  toasts: ToastMessage[];
  addToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;
}

const BakeryStoreContext = createContext<BakeryStoreContextType | null>(null);

const CONVEX_CONFIGURED = Boolean(
  typeof process !== 'undefined' &&
    (process.env.NEXT_PUBLIC_CONVEX_URL || process.env.VITE_CONVEX_URL)
);

const DEFAULT_CATEGORIES: Category[] = [
  { _id: 'cat-1', name: 'Celebration Cakes', slug: 'celebration-cakes', sortOrder: 0 },
  { _id: 'cat-2', name: 'Pastries & Bakes', slug: 'pastries-bakes', sortOrder: 1 },
  { _id: 'cat-3', name: 'Savory Delights', slug: 'savory-delights', sortOrder: 2 },
];

const DEFAULT_PRODUCTS: Product[] = [
  {
    _id: 'prod-1',
    name: 'Vanilla Celebration Cake',
    description:
      'Three layers of tender vanilla sponge with silky Swiss meringue buttercream and fresh florals. Made for weddings, milestone birthdays, and family celebrations.',
    price: 35000,
    categoryId: 'cat-1',
    categoryName: 'Celebration Cakes',
    imageUrl: '/images/cake_vanilla_celebration_1793142929181.jpg',
    isAvailable: true,
    isFeatured: true,
    createdAt: 1710000000000,
  },
  {
    _id: 'prod-2',
    name: 'Dark Chocolate Ganache Cake',
    description:
      'Deep cocoa sponge filled and frosted with smooth Belgian chocolate ganache and delicate chocolate shavings. Baked fresh to order.',
    price: 38000,
    categoryId: 'cat-1',
    categoryName: 'Celebration Cakes',
    imageUrl: '/images/cake_chocolate_fudge_1793142992817.jpg',
    isAvailable: true,
    isFeatured: true,
    createdAt: 1710000100000,
  },
  {
    _id: 'prod-3',
    name: 'Classic Red Velvet Cake',
    description:
      'Traditional velvet crumb layered with real vanilla cream cheese frosting. An enduring centerpiece for birthdays and special gatherings.',
    price: 32000,
    categoryId: 'cat-1',
    categoryName: 'Celebration Cakes',
    imageUrl: '/images/cake_red_velvet_1793142994309.jpg',
    isAvailable: true,
    isFeatured: true,
    createdAt: 1710000200000,
  },
  {
    _id: 'prod-4',
    name: 'Flaky Nigerian Meat Pie',
    description:
      'Golden, buttery pastry filled with well-seasoned minced beef, diced potatoes, and carrots. Freshly baked each morning.',
    price: 2500,
    categoryId: 'cat-3',
    categoryName: 'Savory Delights',
    imageUrl: '/images/pastry_flaky_meat_pie_1793142930485.jpg',
    isAvailable: true,
    isFeatured: true,
    createdAt: 1710000300000,
  },
  {
    _id: 'prod-5',
    name: 'Morning Cinnamon Brioche Rolls',
    description:
      'Soft butter brioche rolled with cinnamon sugar and topped with a light cream cheese glaze. Pack of 4.',
    price: 4500,
    categoryId: 'cat-2',
    categoryName: 'Pastries & Bakes',
    imageUrl: '/images/pastry_cinnamon_rolls_1793143028681.jpg',
    isAvailable: true,
    isFeatured: false,
    createdAt: 1710000400000,
  },
  {
    _id: 'prod-6',
    name: 'Vanilla Glazed Ring Doughnuts',
    description:
      'Golden, slow-fermented brioche doughnuts finished with a delicate vanilla bean glaze. Box of 4.',
    price: 6000,
    categoryId: 'cat-2',
    categoryName: 'Pastries & Bakes',
    imageUrl: '/images/pastry_glazed_doughnuts_1793143028523.jpg',
    isAvailable: true,
    isFeatured: false,
    createdAt: 1710000500000,
  },
];

export function BakeryStoreProvider({ children }: { children: React.ReactNode }) {
  // Filters & UI state
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showUnavailable, setShowUnavailable] = useState<boolean>(true);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Local fallback state if Convex is not yet connected
  const [localProducts, setLocalProducts] = useState<Product[]>(DEFAULT_PRODUCTS);
  const [localCategories, setLocalCategories] = useState<Category[]>(DEFAULT_CATEGORIES);

  // Toast Helpers
  const addToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Convex Auth Actions hook
  const { signIn, signOut } = useAuthActions();

  // Queries (only active when Convex is configured)
  const isAdminQuery = useQuery(api.admin.isAdmin, CONVEX_CONFIGURED ? {} : 'skip');
  const categoriesQuery = useQuery(api.categories.list, CONVEX_CONFIGURED ? {} : 'skip');
  const publicProductsQuery = useQuery(
    api.products.listPublic,
    CONVEX_CONFIGURED ? { showUnavailable: true } : 'skip'
  );
  const adminProductsQuery = useQuery(
    api.products.listAdmin,
    CONVEX_CONFIGURED && isAdminQuery === true ? {} : 'skip'
  );

  // Mutations
  const createProductMutation = useMutation(api.products.createProduct);
  const updateProductMutation = useMutation(api.products.updateProduct);
  const quickPriceMutation = useMutation(api.products.quickUpdatePrice);
  const deleteProductMutation = useMutation(api.products.deleteProduct);
  const createCategoryMutation = useMutation(api.categories.create);
  const updateCategoryMutation = useMutation(api.categories.update);
  const deleteCategoryMutation = useMutation(api.categories.remove);
  const seedMutation = useMutation(api.products.seedSampleProducts);
  const uploadUrlMutation = useMutation(api.products.generateUploadUrl);

  const isAuthenticated = isAdminQuery === true;
  const isAuthLoading = CONVEX_CONFIGURED && isAdminQuery === undefined;

  // Normalized data: prefer Convex when populated, fallback to local sample items
  const categories: Category[] = useMemo(() => {
    if (categoriesQuery && Array.isArray(categoriesQuery) && categoriesQuery.length > 0) {
      return categoriesQuery as Category[];
    }
    return localCategories;
  }, [categoriesQuery, localCategories]);

  // Admin list if authenticated, otherwise public list
  const products: Product[] = useMemo(() => {
    if (isAuthenticated && adminProductsQuery && Array.isArray(adminProductsQuery) && adminProductsQuery.length > 0) {
      return adminProductsQuery as Product[];
    }
    if (publicProductsQuery && Array.isArray(publicProductsQuery) && publicProductsQuery.length > 0) {
      return publicProductsQuery as Product[];
    }
    return localProducts;
  }, [isAuthenticated, adminProductsQuery, publicProductsQuery, localProducts]);

  const isLoading =
    CONVEX_CONFIGURED && (categoriesQuery === undefined || publicProductsQuery === undefined);

  // Login handler using Convex Auth signIn flow
  const login = async (
    email: string,
    pass: string
  ): Promise<{ success: boolean; error?: string }> => {
    if (!CONVEX_CONFIGURED) {
      return { success: false, error: 'Incorrect email or password.' };
    }

    try {
      await signIn('password', {
        email: email.trim().toLowerCase(),
        password: pass,
        flow: 'signIn',
      });
      addToast('Administrator authenticated successfully.', 'success');
      return { success: true };
    } catch {
      return { success: false, error: 'Incorrect email or password.' };
    }
  };

  const logout = async () => {
    try {
      await signOut();
      addToast('Signed out of Administrator Portal.', 'info');
    } catch (e: any) {
      console.error('Logout error:', e);
    }
  };

  // Admin Actions
  const generateUploadUrl = async (): Promise<string> => {
    if (CONVEX_CONFIGURED) {
      return await uploadUrlMutation();
    }
    return '';
  };

  const addProduct = async (productData: {
    name: string;
    description: string;
    price: number;
    categoryId: string;
    imageUrl?: string | null;
    imageStorageId?: string;
    isAvailable: boolean;
    isFeatured: boolean;
  }) => {
    if (CONVEX_CONFIGURED) {
      const res = await createProductMutation({
        name: productData.name,
        description: productData.description,
        price: productData.price,
        categoryId: productData.categoryId as any,
        imageUrl: productData.imageUrl || undefined,
        imageStorageId: productData.imageStorageId as any,
        isAvailable: productData.isAvailable,
        isFeatured: productData.isFeatured,
      });
      addToast(`"${productData.name}" created successfully.`, 'success');
      return res;
    } else {
      const newProd: Product = {
        _id: `prod-${Date.now()}`,
        name: productData.name,
        description: productData.description,
        price: productData.price,
        categoryId: productData.categoryId,
        categoryName: categories.find((c) => c._id === productData.categoryId)?.name || 'Pastries',
        imageUrl: productData.imageUrl,
        isAvailable: productData.isAvailable,
        isFeatured: productData.isFeatured,
        createdAt: Date.now(),
      };
      setLocalProducts((prev) => [newProd, ...prev]);
      addToast(`"${productData.name}" created successfully.`, 'success');
      return newProd._id;
    }
  };

  const updateProduct = async (id: string, updates: Partial<Product>) => {
    const existing = products.find((p) => p._id === id);
    if (!existing) return;

    if (CONVEX_CONFIGURED) {
      await updateProductMutation({
        id: id as any,
        name: updates.name ?? existing.name,
        description: updates.description ?? existing.description,
        price: updates.price ?? existing.price,
        categoryId: (updates.categoryId ?? existing.categoryId) as any,
        imageUrl: (updates.imageUrl ?? existing.imageUrl) || undefined,
        imageStorageId: (updates.imageStorageId ?? existing.imageStorageId) as any,
        isAvailable: updates.isAvailable ?? existing.isAvailable,
        isFeatured: updates.isFeatured ?? existing.isFeatured,
      });
    } else {
      setLocalProducts((prev) =>
        prev.map((p) =>
          p._id === id
            ? {
                ...p,
                ...updates,
                categoryName: updates.categoryId
                  ? categories.find((c) => c._id === updates.categoryId)?.name
                  : p.categoryName,
              }
            : p
        )
      );
    }
    addToast('Product updated successfully.', 'success');
  };

  const quickUpdatePrice = async (id: string, newPrice: number) => {
    if (CONVEX_CONFIGURED) {
      await quickPriceMutation({ id: id as any, price: newPrice });
    } else {
      setLocalProducts((prev) =>
        prev.map((p) => (p._id === id ? { ...p, price: Math.round(newPrice) } : p))
      );
    }
    addToast('Price updated.', 'success');
  };

  const deleteProduct = async (id: string) => {
    const target = products.find((p) => p._id === id);
    if (CONVEX_CONFIGURED) {
      await deleteProductMutation({ id: id as any });
    } else {
      setLocalProducts((prev) => prev.filter((p) => p._id !== id));
    }
    addToast(`"${target?.name || 'Item'}" deleted.`, 'info');
  };

  const addCategory = async (name: string) => {
    if (CONVEX_CONFIGURED) {
      const res = await createCategoryMutation({ name });
      addToast(`Category "${name}" created.`, 'success');
      return res;
    } else {
      const newCat: Category = {
        _id: `cat-${Date.now()}`,
        name,
        slug: name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
        sortOrder: localCategories.length,
      };
      setLocalCategories((prev) => [...prev, newCat]);
      addToast(`Category "${name}" created.`, 'success');
      return newCat._id;
    }
  };

  const updateCategory = async (id: string, name: string) => {
    if (CONVEX_CONFIGURED) {
      await updateCategoryMutation({ id: id as any, name });
    } else {
      setLocalCategories((prev) =>
        prev.map((c) =>
          c._id === id
            ? { ...c, name, slug: name.toLowerCase().replace(/[^a-z0-9]+/g, '-') }
            : c
        )
      );
    }
    addToast('Category renamed successfully.', 'success');
  };

  const deleteCategory = async (id: string) => {
    try {
      if (CONVEX_CONFIGURED) {
        await deleteCategoryMutation({ id: id as any });
      } else {
        setLocalCategories((prev) => prev.filter((c) => c._id !== id));
      }
      addToast('Category removed.', 'info');
    } catch (err: any) {
      addToast(err?.message || 'Failed to delete category.', 'error');
    }
  };

  const seedSampleProducts = async () => {
    try {
      if (CONVEX_CONFIGURED) {
        await seedMutation();
      } else {
        setLocalProducts(DEFAULT_PRODUCTS);
        setLocalCategories(DEFAULT_CATEGORIES);
      }
      addToast('Sample bakery items seeded.', 'success');
    } catch (err: any) {
      addToast(err?.message || 'Failed to seed sample items.', 'error');
    }
  };

  // Filtered public products
  const publicProducts = useMemo(() => {
    return products.filter((p) => {
      if (selectedCategory !== 'all' && p.categoryId !== selectedCategory) {
        return false;
      }
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesName = p.name.toLowerCase().includes(query);
        const matchesDesc = p.description.toLowerCase().includes(query);
        if (!matchesName && !matchesDesc) return false;
      }
      if (!showUnavailable && !p.isAvailable) {
        return false;
      }
      return true;
    });
  }, [products, selectedCategory, searchQuery, showUnavailable]);

  const featuredProducts = useMemo(() => {
    return products.filter((p) => p.isFeatured && p.isAvailable);
  }, [products]);

  return (
    <BakeryStoreContext.Provider
      value={{
        categories,
        products,
        publicProducts,
        featuredProducts,
        isLoading,
        isConvexConnected: CONVEX_CONFIGURED,
        selectedCategory,
        setSelectedCategory,
        searchQuery,
        setSearchQuery,
        showUnavailable,
        setShowUnavailable,
        isAuthenticated,
        isAuthLoading,
        login,
        logout,
        addProduct,
        updateProduct,
        quickUpdatePrice,
        deleteProduct,
        addCategory,
        updateCategory,
        deleteCategory,
        seedSampleProducts,
        generateUploadUrl,
        toasts,
        addToast,
        removeToast,
      }}
    >
      {children}
    </BakeryStoreContext.Provider>
  );
}

export function useBakeryStore() {
  const context = useContext(BakeryStoreContext);
  if (!context) {
    throw new Error('useBakeryStore must be used within a BakeryStoreProvider');
  }
  return context;
}
