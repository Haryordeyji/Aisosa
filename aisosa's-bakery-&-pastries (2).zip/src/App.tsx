import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { ConvexClientProvider } from '../components/ConvexClientProvider';
import { ToastContainer } from '../components/Toasts';
import HomePage from '../app/page';
import MenuPage from '../app/menu/page';
import AboutPage from '../app/about/page';
import ContactPage from '../app/contact/page';
import AdminPage from '../app/admin/page';
import AdminLoginPage from '../app/admin/login/page';

function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}

export default function App() {
  return (
    <ConvexClientProvider>
      <BrowserRouter>
        <ScrollToTop />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/menu" element={<MenuPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/admin" element={<AdminPage />} />
          <Route path="/admin/login" element={<AdminLoginPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
        <ToastContainer />
      </BrowserRouter>
    </ConvexClientProvider>
  );
}
