export function Montserrat(_options?: any) {
  return {
    className: 'font-heading',
    variable: '--font-heading',
    style: { fontFamily: "'Montserrat', system-ui, sans-serif" },
  };
}

export function Open_Sans(_options?: any) {
  return {
    className: 'font-sans',
    variable: '--font-sans',
    style: { fontFamily: "'Open Sans', system-ui, sans-serif" },
  };
}

export function Dancing_Script(_options?: any) {
  return {
    className: 'font-brand',
    variable: '--font-brand',
    style: { fontFamily: "'Dancing Script', cursive, sans-serif" },
  };
}

export function Playfair_Display(_options?: any) {
  return {
    className: 'font-heading',
    variable: '--font-heading',
    style: { fontFamily: "'Montserrat', system-ui, sans-serif" },
  };
}

export function Plus_Jakarta_Sans(_options?: any) {
  return {
    className: 'font-sans',
    variable: '--font-sans',
    style: { fontFamily: "'Open Sans', system-ui, sans-serif" },
  };
}
