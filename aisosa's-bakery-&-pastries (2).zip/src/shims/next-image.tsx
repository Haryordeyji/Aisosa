import React, { useState } from 'react';

export default function Image({
  src,
  alt,
  fill,
  width,
  height,
  className = '',
  priority,
  sizes,
  referrerPolicy = 'no-referrer',
  style = {},
  ...props
}: any) {
  const [hasError, setHasError] = useState(false);

  const fallbackSrc = '/images/hero_bakery_showcase_1793142927975.jpg';

  const fillStyle: React.CSSProperties = fill
    ? {
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        objectFit: 'cover',
        ...style,
      }
    : style;

  return (
    <img
      src={hasError ? fallbackSrc : src || fallbackSrc}
      alt={alt || "Aisosa's Bakery & Pastries"}
      className={className}
      style={fillStyle}
      width={width}
      height={height}
      loading={priority ? 'eager' : 'lazy'}
      referrerPolicy={referrerPolicy}
      onError={() => {
        if (!hasError) setHasError(true);
      }}
      {...props}
    />
  );
}
