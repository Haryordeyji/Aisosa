import React from 'react';
import { Link as RouterLink } from 'react-router-dom';

export default function Link({
  href = '/',
  children,
  className,
  onClick,
  target,
  rel,
  ...props
}: any) {
  if (
    typeof href === 'string' &&
    (href.startsWith('http://') ||
      href.startsWith('https://') ||
      href.startsWith('tel:') ||
      href.startsWith('mailto:'))
  ) {
    return (
      <a
        href={href}
        className={className}
        onClick={onClick}
        target={target}
        rel={rel}
        {...props}
      >
        {children}
      </a>
    );
  }
  return (
    <RouterLink
      to={href}
      className={className}
      onClick={onClick}
      target={target}
      rel={rel}
      {...props}
    >
      {children}
    </RouterLink>
  );
}
