export interface BakeryConfig {
  brandName: string;
  shortName: string;
  tagline: string;
  description: string;
  phoneRaw: string;
  phoneDisplay: string;
  whatsappUrl: string;
  instagramUrl: string;
  instagramHandle: string;
  address: string;
  openingHours: string;
  currencySymbol: string;
  currencyCode: string;
}

export const BAKERY_CONFIG: BakeryConfig = {
  brandName: "Aisosa's Bakery and Pastries",
  shortName: "Aisosa's Bakery",
  tagline: "Cakes & Pastries",
  description: "Cakes and pastries for every occasion. Birthday cakes, wedding cakes, meat pies and more.",

  // Phone / Call: +2349053322931 (display as "+234 905 332 2931")
  phoneRaw: "2349053322931",
  phoneDisplay: "+234 905 332 2931",

  // WhatsApp: use https://wa.link/56tndi exactly
  whatsappUrl: "https://wa.link/56tndi",

  // Instagram: https://www.instagram.com/aisosa.iguma (@aisosa.iguma)
  instagramUrl: "https://www.instagram.com/aisosa.iguma",
  instagramHandle: "@aisosa.iguma",

  // Empty strings: only rendered when not empty
  address: "",
  openingHours: "",

  currencySymbol: "₦",
  currencyCode: "NGN",
};

export const getWhatsAppLink = (_customText?: string) => {
  return BAKERY_CONFIG.whatsappUrl;
};

export const getCallLink = () => {
  return `tel:+${BAKERY_CONFIG.phoneRaw}`;
};
