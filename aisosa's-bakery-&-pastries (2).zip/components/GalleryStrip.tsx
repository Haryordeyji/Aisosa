'use client';

import React from 'react';
import Image from 'next/image';

const GALLERY_IMAGES = [
  {
    src: '/images/cake_vanilla_celebration_1793142929181.jpg',
    alt: 'Tiered celebration cake',
    caption: 'Celebration cakes',
  },
  {
    src: '/images/pastry_flaky_meat_pie_1793142930485.jpg',
    alt: 'Freshly baked meat pies',
    caption: 'Meat pies',
  },
  {
    src: '/images/cake_chocolate_fudge_1793142992817.jpg',
    alt: 'Chocolate ganache cake',
    caption: 'Chocolate cakes',
  },
  {
    src: '/images/pastry_cinnamon_rolls_1793143028681.jpg',
    alt: 'Cinnamon rolls with glaze',
    caption: 'Cinnamon rolls',
  },
  {
    src: '/images/cake_red_velvet_1793142994309.jpg',
    alt: 'Red velvet cake slice',
    caption: 'Red velvet',
  },
  {
    src: '/images/pastry_glazed_doughnuts_1793143028523.jpg',
    alt: 'Glazed ring doughnuts',
    caption: 'Glazed doughnuts',
  },
];

export function GalleryStrip() {
  return (
    <section className="py-16 sm:py-24 bg-white border-b border-[#3B2418]/10">
      <div className="max-w-[1240px] mx-auto px-6 sm:px-8">
        <div className="mb-12 text-center max-w-xl mx-auto">
          <span className="text-[14px] sm:text-[15px] font-semibold text-[#B8913B] mb-1.5 block">
            Photo gallery
          </span>
          <h2 className="font-heading text-3xl sm:text-4xl font-bold text-[#3B2418]">
            A look at our bakes
          </h2>
          <p className="mt-2 text-[17px] lg:text-[18px] text-[#6B4A3A]">
            A quick photo look at some of the cakes, pies, and morning bakes we make.
          </p>
        </div>

        {/* Responsive Grid with rounded-xl photos and smooth hover effect */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-5">
          {GALLERY_IMAGES.map((img, idx) => (
            <div
              key={idx}
              className="group relative aspect-square rounded-2xl overflow-hidden bg-[#FAF6F0] shadow-sm border border-[#3B2418]/10 hover:border-[#B8913B]/50 hover:shadow-lg transition-all duration-300"
            >
              <Image
                src={img.src}
                alt={img.alt}
                fill
                className="object-cover group-hover:scale-108 transition-transform duration-500 ease-out"
                sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 16vw"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#3B2418]/85 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-3.5">
                <span className="text-[14px] font-bold text-white drop-shadow-sm">
                  {img.caption}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
