'use client';

import React from 'react';

interface BrandWordmarkProps {
  color?: 'white' | 'brown' | 'ivory' | 'auto';
  isSolid?: boolean;
  isShrunk?: boolean;
  className?: string;
}

export function BrandWordmark({
  color = 'auto',
  isSolid = false,
  isShrunk = false,
  className = '',
}: BrandWordmarkProps) {
  let textColorClass = 'text-[#3B2418]';
  let subColorClass = 'text-[#6B4A3A]';

  if (color === 'white' || (color === 'auto' && !isSolid)) {
    textColorClass = 'text-white';
    subColorClass = 'text-white/90';
  } else if (color === 'ivory') {
    textColorClass = 'text-[#FAF6F0]';
    subColorClass = 'text-[#FAF6F0]/85';
  } else if (color === 'brown' || (color === 'auto' && isSolid)) {
    textColorClass = 'text-[#3B2418]';
    subColorClass = 'text-[#6B4A3A]';
  }

  return (
    <div className={`flex flex-col select-none ${className}`}>
      {/* First line: "Aisosa's Bakery" in Dancing Script */}
      <span
        className={`font-brand font-bold leading-[1.15] transition-all duration-300 group-hover:text-[#B8913B] ${textColorClass} ${
          isShrunk
            ? 'text-[24px] sm:text-[28px]'
            : 'text-[26px] sm:text-[34px]'
        }`}
      >
        Aisosa&apos;s Bakery
      </span>

      {/* Second line: "and Pastries" also in Dancing Script */}
      <span
        className={`font-brand font-bold leading-[1.15] transition-all duration-300 group-hover:text-[#B8913B] -mt-1 sm:-mt-2 ${subColorClass} ${
          isShrunk
            ? 'text-[16px] sm:text-[19px]'
            : 'text-[18px] sm:text-[22px]'
        }`}
      >
        and Pastries
      </span>
    </div>
  );
}
