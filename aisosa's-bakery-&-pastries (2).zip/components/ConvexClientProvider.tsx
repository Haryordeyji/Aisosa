'use client';

import React, { useMemo } from 'react';
import { ConvexReactClient } from 'convex/react';
import { ConvexAuthProvider } from '@convex-dev/auth/react';
import { BakeryStoreProvider } from '@/lib/store';

// Safely obtain Convex URL or fall back to dummy string so ConvexReactClient does not throw on empty url
const rawConvexUrl =
  process.env.NEXT_PUBLIC_CONVEX_URL ||
  process.env.VITE_CONVEX_URL ||
  '';

export function ConvexClientProvider({ children }: { children: React.ReactNode }) {
  const convexClient = useMemo(() => {
    const url = rawConvexUrl.trim() || 'https://placeholder.convex.cloud';
    return new ConvexReactClient(url, {
      // Disable auto reconnection attempts when placeholder is used
      unsavedChangesWarning: false,
    });
  }, []);

  return (
    <ConvexAuthProvider client={convexClient}>
      <BakeryStoreProvider>{children}</BakeryStoreProvider>
    </ConvexAuthProvider>
  );
}
