'use client';

import React from 'react';
import { Phone, Instagram } from 'lucide-react';
import { BAKERY_CONFIG, getWhatsAppLink, getCallLink } from '@/src/config';

function WhatsAppIcon({ className = 'w-5 h-5' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.472 14.382c-.301-.15-1.781-.878-2.056-.978-.276-.1-.476-.15-.676.15-.2.301-.776.978-.951 1.178-.175.201-.351.226-.652.076-.301-.15-1.272-.469-2.424-1.496-.896-.799-1.5-1.788-1.676-2.088-.176-.301-.019-.464.132-.614.136-.135.301-.351.451-.527.15-.175.2-.3.301-.501.1-.201.05-.376-.025-.526-.075-.15-.677-1.631-.927-2.233-.243-.586-.49-.506-.676-.516l-.576-.01c-.2 0-.526.075-.802.376-.275.301-1.052 1.028-1.052 2.508 0 1.48 1.077 2.909 1.227 3.109.15.201 2.12 3.238 5.137 4.542.717.31 1.277.496 1.713.635.72.23 1.375.197 1.892.12.576-.086 1.781-.728 2.032-1.431.25-.702.25-1.304.175-1.43-.075-.126-.275-.201-.576-.351zM12.04 2C6.516 2 2.025 6.49 2.025 12.015c0 1.956.564 3.784 1.542 5.334L2 22.025l4.825-1.523c1.487.917 3.23 1.442 5.215 1.442 5.525 0 10.015-4.49 10.015-10.015C22.055 6.49 17.565 2 12.04 2z" />
    </svg>
  );
}

export function ContactSection() {
  return (
    <section className="py-16 sm:py-24 bg-[#FAF6F0] border-b border-[#3B2418]/10">
      <div className="max-w-[1240px] mx-auto px-6 sm:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 lg:gap-14 items-center">
          {/* Left Column: Direct contact info */}
          <div className="md:col-span-6">
            <span className="text-[14px] sm:text-[15px] font-semibold text-[#B8913B] mb-1.5 block">
              We are here to help
            </span>
            <h2 className="font-heading text-3xl sm:text-4xl font-bold text-[#3B2418]">
              Contact us
            </h2>
            <p className="mt-3 text-[17px] lg:text-[18px] text-[#6B4A3A] leading-relaxed max-w-lg">
              Have a question about an upcoming celebration or want to order? Reach out on WhatsApp or give us a call.
            </p>

            <div className="mt-8 space-y-4">
              {/* WhatsApp */}
              <div className="flex items-center gap-4 bg-white p-4.5 rounded-xl border border-[#3B2418]/10 hover:border-[#B8913B]/40 transition-colors">
                <div className="w-11 h-11 rounded-lg bg-[#FAF6F0] flex items-center justify-center text-[#B8913B] shrink-0">
                  <WhatsAppIcon className="w-5 h-5 fill-current" />
                </div>
                <div>
                  <span className="text-[13px] font-semibold text-[#6B4A3A] block">
                    WhatsApp chat
                  </span>
                  <a
                    href={getWhatsAppLink()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[16px] sm:text-[17px] font-bold text-[#3B2418] hover:text-[#B8913B] transition-colors"
                  >
                    Chat directly on WhatsApp
                  </a>
                </div>
              </div>

              {/* Phone */}
              <div className="flex items-center gap-4 bg-white p-4.5 rounded-xl border border-[#3B2418]/10 hover:border-[#B8913B]/40 transition-colors">
                <div className="w-11 h-11 rounded-lg bg-[#FAF6F0] flex items-center justify-center text-[#B8913B] shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[13px] font-semibold text-[#6B4A3A] block">
                    Telephone call
                  </span>
                  <a
                    href={getCallLink()}
                    className="text-[16px] sm:text-[17px] font-bold text-[#3B2418] hover:text-[#B8913B] transition-colors"
                  >
                    {BAKERY_CONFIG.phoneDisplay}
                  </a>
                </div>
              </div>

              {/* Instagram */}
              <div className="flex items-center gap-4 bg-white p-4.5 rounded-xl border border-[#3B2418]/10 hover:border-[#B8913B]/40 transition-colors">
                <div className="w-11 h-11 rounded-lg bg-[#FAF6F0] flex items-center justify-center text-[#B8913B] shrink-0">
                  <Instagram className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[13px] font-semibold text-[#6B4A3A] block">
                    Instagram photos
                  </span>
                  <a
                    href={BAKERY_CONFIG.instagramUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[16px] sm:text-[17px] font-bold text-[#3B2418] hover:text-[#B8913B] transition-colors"
                  >
                    {BAKERY_CONFIG.instagramHandle}
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Simple card with heading and two buttons */}
          <div className="md:col-span-6 bg-white p-8 sm:p-12 rounded-2xl border border-[#3B2418]/10 shadow-sm text-center">
            <span className="text-[14px] sm:text-[15px] font-semibold text-[#B8913B] mb-2 block">
              Quick inquiry
            </span>
            <h3 className="font-heading text-2xl sm:text-3xl font-bold text-[#3B2418]">
              Ready to order or have a question?
            </h3>
            <p className="mt-3 text-[17px] text-[#6B4A3A] max-w-md mx-auto">
              Send us a message or call directly to ask about prices, designs, and date availability.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href={getWhatsAppLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-[#B8913B] hover:bg-[#a68030] text-white text-[16px] font-bold rounded-md shadow-xs hover:shadow-sm hover:-translate-y-0.5 transition-all"
              >
                <WhatsAppIcon className="w-4 h-4 fill-current shrink-0" />
                <span>Chat on WhatsApp</span>
              </a>

              <a
                href={getCallLink()}
                className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-transparent hover:bg-[#3B2418]/5 text-[#3B2418] text-[16px] font-bold rounded-md border border-[#3B2418]/30 hover:border-[#3B2418] transition-all"
              >
                <Phone className="w-4 h-4 text-[#B8913B]" />
                <span>Call {BAKERY_CONFIG.phoneDisplay}</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
