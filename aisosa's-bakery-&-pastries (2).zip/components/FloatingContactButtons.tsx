'use client';

import React from 'react';
import { Phone } from 'lucide-react';
import { BAKERY_CONFIG, getWhatsAppLink, getCallLink } from '@/src/config';

function WhatsAppIcon({ className = 'w-5 h-5' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.472 14.382c-.301-.15-1.781-.878-2.056-.978-.276-.1-.476-.15-.676.15-.2.301-.776.978-.951 1.178-.175.201-.351.226-.652.076-.301-.15-1.272-.469-2.424-1.496-.896-.799-1.5-1.788-1.676-2.088-.176-.301-.019-.464.132-.614.136-.135.301-.351.451-.527.15-.175.2-.3.301-.501.1-.201.05-.376-.025-.526-.075-.15-.677-1.631-.927-2.233-.243-.586-.49-.506-.676-.516l-.576-.01c-.2 0-.526.075-.802.376-.275.301-1.052 1.028-1.052 2.508 0 1.48 1.077 2.909 1.227 3.109.15.201 2.12 3.238 5.137 4.542.717.31 1.277.496 1.713.635.72.23 1.375.197 1.892.12.576-.086 1.781-.728 2.032-1.431.25-.702.25-1.304.175-1.43-.075-.126-.275-.201-.576-.351zM12.04 2C6.516 2 2.025 6.49 2.025 12.015c0 1.956.564 3.784 1.542 5.334L2 22.025l4.825-1.523c1.487.917 3.23 1.442 5.215 1.442 5.525 0 10.015-4.49 10.015-10.015C22.055 6.49 17.565 2 12.04 2z" />
    </svg>
  );
}

export function FloatingContactButtons() {
  return (
    <aside
      aria-label="Direct contact buttons"
      className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3 pointer-events-auto"
    >
      {/* Call button */}
      <a
        href={getCallLink()}
        aria-label={`Call ${BAKERY_CONFIG.shortName} at ${BAKERY_CONFIG.phoneDisplay}`}
        className="flex items-center gap-2.5 px-4 py-3 bg-[#3B2418] hover:bg-[#2A180E] text-[#FAF6F0] rounded-full shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all group"
      >
        <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center shrink-0 group-hover:bg-[#B8913B] transition-colors">
          <Phone className="w-4 h-4 text-[#FAF6F0]" />
        </div>
        <span className="text-[14px] font-bold pr-1 whitespace-nowrap">
          Call us
        </span>
      </a>

      {/* WhatsApp button with authentic WhatsApp icon */}
      <a
        href={getWhatsAppLink()}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat on WhatsApp with Aisosa's Bakery"
        className="flex items-center gap-2.5 px-4 py-3 bg-[#B8913B] hover:bg-[#a68030] text-white rounded-full shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all group"
      >
        <div className="w-8 h-8 rounded-full bg-white/15 flex items-center justify-center shrink-0 group-hover:bg-white/25 transition-colors">
          <WhatsAppIcon className="w-4 h-4 fill-white" />
        </div>
        <span className="text-[14px] font-bold pr-1 whitespace-nowrap">
          WhatsApp
        </span>
      </a>
    </aside>
  );
}
