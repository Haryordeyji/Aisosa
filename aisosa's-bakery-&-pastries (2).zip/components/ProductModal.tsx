'use client';

import React from 'react';
import Image from 'next/image';
import { X, Phone } from 'lucide-react';
import { Product } from '@/lib/store';
import { formatNaira } from '@/lib/utils';
import { BAKERY_CONFIG, getWhatsAppLink, getCallLink } from '@/src/config';

function WhatsAppIcon({ className = 'w-4 h-4' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.472 14.382c-.301-.15-1.781-.878-2.056-.978-.276-.1-.476-.15-.676.15-.2.301-.776.978-.951 1.178-.175.201-.351.226-.652.076-.301-.15-1.272-.469-2.424-1.496-.896-.799-1.5-1.788-1.676-2.088-.176-.301-.019-.464.132-.614.136-.135.301-.351.451-.527.15-.175.2-.3.301-.501.1-.201.05-.376-.025-.526-.075-.15-.677-1.631-.927-2.233-.243-.586-.49-.506-.676-.516l-.576-.01c-.2 0-.526.075-.802.376-.275.301-1.052 1.028-1.052 2.508 0 1.48 1.077 2.909 1.227 3.109.15.201 2.12 3.238 5.137 4.542.717.31 1.277.496 1.713.635.72.23 1.375.197 1.892.12.576-.086 1.781-.728 2.032-1.431.25-.702.25-1.304.175-1.43-.075-.126-.275-.201-.576-.351zM12.04 2C6.516 2 2.025 6.49 2.025 12.015c0 1.956.564 3.784 1.542 5.334L2 22.025l4.825-1.523c1.487.917 3.23 1.442 5.215 1.442 5.525 0 10.015-4.49 10.015-10.015C22.055 6.49 17.565 2 12.04 2z" />
    </svg>
  );
}

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
}

export function ProductModal({ product, onClose }: ProductModalProps) {
  if (!product) return null;

  const enquiryText = `Hello Aisosa's Bakery, I would like to ask about "${product.name}" (${formatNaira(
    product.price
  )}). Is it available?`;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
    >
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-[#3B2418]/60 backdrop-blur-xs transition-opacity"
      />

      {/* Modal Card */}
      <div className="relative w-full max-w-xl bg-white rounded-2xl border border-[#3B2418]/15 shadow-2xl overflow-hidden z-10">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-9 h-9 bg-white/95 hover:bg-[#3B2418] text-[#3B2418] hover:text-white rounded-full flex items-center justify-center transition-colors shadow-sm"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex flex-col">
          {/* Photo */}
          <div className="relative w-full aspect-[16/10] bg-[#FAF6F0]">
            {product.imageUrl ? (
              <Image
                src={product.imageUrl}
                alt={product.name}
                fill
                className="object-cover"
                sizes="(max-width: 640px) 100vw, 600px"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-lg font-bold text-[#6B4A3A]">
                Aisosa&apos;s Bakery
              </div>
            )}
          </div>

          {/* Details */}
          <div className="p-6 sm:p-8 flex flex-col justify-between gap-6">
            <div>
              <span className="text-[14px] font-semibold text-[#B8913B] block">
                {product.categoryName || 'Bakery Item'}
              </span>

              <h2 className="font-heading text-2xl sm:text-3xl font-bold text-[#3B2418] mt-1.5 leading-snug">
                {product.name}
              </h2>

              <div className="mt-3 text-xl sm:text-2xl font-bold text-[#3B2418] tabular-nums">
                {formatNaira(product.price)}
              </div>

              <p className="mt-3 text-[17px] text-[#6B4A3A] leading-relaxed">
                {product.description}
              </p>

              <div className="mt-5 p-4 bg-[#FAF6F0] rounded-xl border border-[#3B2418]/10 text-[#3B2418]">
                <p className="text-[15px] font-semibold">Baked fresh to order.</p>
                <p className="text-[13px] text-[#6B4A3A] mt-0.5">
                  Message us on WhatsApp or call to ask about today&apos;s availability.
                </p>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-[#3B2418]/10">
              <a
                href={getWhatsAppLink(enquiryText)}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 text-center py-3.5 px-4 bg-[#B8913B] hover:bg-[#a68030] text-white text-[15px] font-bold rounded-md shadow-sm hover:shadow-md transition-all flex items-center justify-center gap-2"
              >
                <WhatsAppIcon className="w-4 h-4 fill-current shrink-0" />
                <span>Chat on WhatsApp</span>
              </a>

              <a
                href={getCallLink()}
                className="flex-1 text-center py-3.5 px-4 bg-transparent hover:bg-[#3B2418]/5 text-[#3B2418] text-[15px] font-bold rounded-md border border-[#3B2418]/30 hover:border-[#3B2418] transition-all flex items-center justify-center gap-2"
              >
                <Phone className="w-4 h-4 text-[#B8913B]" />
                <span>Call {BAKERY_CONFIG.phoneDisplay}</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
