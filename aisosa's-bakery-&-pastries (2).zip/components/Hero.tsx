'use client';

import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { getWhatsAppLink } from '@/src/config';
import { ChevronDown, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

function WhatsAppIcon({ className = 'w-4 h-4' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.472 14.382c-.301-.15-1.781-.878-2.056-.978-.276-.1-.476-.15-.676.15-.2.301-.776.978-.951 1.178-.175.201-.351.226-.652.076-.301-.15-1.272-.469-2.424-1.496-.896-.799-1.5-1.788-1.676-2.088-.176-.301-.019-.464.132-.614.136-.135.301-.351.451-.527.15-.175.2-.3.301-.501.1-.201.05-.376-.025-.526-.075-.15-.677-1.631-.927-2.233-.243-.586-.49-.506-.676-.516l-.576-.01c-.2 0-.526.075-.802.376-.275.301-1.052 1.028-1.052 2.508 0 1.48 1.077 2.909 1.227 3.109.15.201 2.12 3.238 5.137 4.542.717.31 1.277.496 1.713.635.72.23 1.375.197 1.892.12.576-.086 1.781-.728 2.032-1.431.25-.702.25-1.304.175-1.43-.075-.126-.275-.201-.576-.351zM12.04 2C6.516 2 2.025 6.49 2.025 12.015c0 1.956.564 3.784 1.542 5.334L2 22.025l4.825-1.523c1.487.917 3.23 1.442 5.215 1.442 5.525 0 10.015-4.49 10.015-10.015C22.055 6.49 17.565 2 12.04 2z" />
    </svg>
  );
}

export function Hero() {
  const [scrollY, setScrollY] = useState(0);
  const [mouseTilt, setMouseTilt] = useState({ x: 0, y: 0 });
  const [isTouchDevice, setIsTouchDevice] = useState(false);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);

  // Card alternation state: 0 = Cake in front, 1 = Meat Pie in front
  const [activeCard, setActiveCard] = useState<0 | 1>(0);
  const [isCardGroupHovered, setIsCardGroupHovered] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const heroRef = useRef<HTMLElement>(null);

  useEffect(() => {
    // Detect touch device to disable mouse tilt
    const checkTouch = () => {
      setIsTouchDevice(
        'ontouchstart' in window ||
          navigator.maxTouchPoints > 0 ||
          window.matchMedia('(pointer: coarse)').matches
      );
    };
    checkTouch();

    // Check prefers-reduced-motion
    const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setPrefersReducedMotion(motionQuery.matches);
    const motionHandler = (e: MediaQueryListEvent) => {
      setPrefersReducedMotion(e.matches);
    };
    motionQuery.addEventListener('change', motionHandler);

    const handleScroll = () => {
      setScrollY(window.scrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
      motionQuery.removeEventListener('change', motionHandler);
    };
  }, []);

  // Cleanup alternation timer on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, []);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (isTouchDevice || prefersReducedMotion || !heroRef.current) return;
    const rect = heroRef.current.getBoundingClientRect();
    const x = (e.clientX - (rect.left + rect.width / 2)) / (rect.width / 2);
    const y = (e.clientY - (rect.top + rect.height / 2)) / (rect.height / 2);
    setMouseTilt({
      x: Math.max(-10, Math.min(10, -y * 10)),
      y: Math.max(-10, Math.min(10, x * 10)),
    });
  };

  const handleMouseLeave = () => {
    setMouseTilt({ x: 0, y: 0 });
  };

  // Card group hover handlers: alternate cards every 1.8s, swap on enter, settle on leave
  const handleCardsMouseEnter = () => {
    if (isTouchDevice) return;
    setIsCardGroupHovered(true);

    if (!prefersReducedMotion) {
      // Immediate swap on hover enter
      setActiveCard((prev) => (prev === 0 ? 1 : 0));

      // Keep alternating automatically every 1.8s while cursor stays on group
      if (intervalRef.current) clearInterval(intervalRef.current);
      intervalRef.current = setInterval(() => {
        setActiveCard((prev) => (prev === 0 ? 1 : 0));
      }, 1800);
    }
  };

  const handleCardsMouseLeave = () => {
    setIsCardGroupHovered(false);
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    // Settle smoothly back to original arrangement when cursor leaves
    setActiveCard(0);
  };

  // Click / Tap to bring card to front immediately (works on mobile and desktop)
  const handleCardClick = (index: 0 | 1) => {
    setActiveCard(index);
  };

  // Keyboard focus to bring card to front immediately
  const handleCardFocus = (index: 0 | 1) => {
    setActiveCard(index);
  };

  // Parallax calculations
  const layer1TranslateY = scrollY * 0.3; // Moves upward ~30% slower than page
  const layer1Blur = Math.min(scrollY * 0.018, 5); // Subtle blur effect on scroll
  const layer2TranslateY = scrollY * 0.16; // Text moves slightly slower
  const layer2Opacity = Math.max(0, 1 - scrollY / 620); // Fades out as user scrolls

  // Differential scroll depth speeds for 3D cards
  const card1ScrollY = scrollY * 0.12;
  const card2ScrollY = scrollY * 0.22;
  const card3ScrollY = scrollY * 0.16;

  const handleScrollDownClick = () => {
    const nextSection =
      document.getElementById('featured-section') ||
      document.querySelector('section:nth-of-type(2)');
    if (nextSection) {
      nextSection.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.scrollTo({ top: window.innerHeight * 0.85, behavior: 'smooth' });
    }
  };

  // Spring transition: 0.6s smooth spring; instant if reduced motion
  const springTransition = prefersReducedMotion
    ? { duration: 0 }
    : {
        type: 'spring' as const,
        stiffness: 240,
        damping: 24,
        mass: 0.9,
      };

  return (
    <section
      ref={heroRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="relative w-full min-h-[85vh] md:min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* LAYER 1 (BACK): Large bakery photo moving ~30% slower with solid brown overlay (rgba(59,36,24,0.55)) & subtle blur on scroll */}
      <div
        className="absolute inset-0 w-full h-[125%] -top-[12%] pointer-events-none will-change-transform"
        style={{
          transform: `translate3d(0, ${layer1TranslateY}px, 0)`,
          filter: `blur(${layer1Blur}px)`,
          transition: 'filter 0.1s linear',
        }}
      >
        <Image
          src="/images/hero_bakery_showcase_1793142927975.jpg"
          alt="Freshly baked celebration cakes and pastries"
          fill
          priority
          className="object-cover object-center"
          sizes="100vw"
        />
        {/* Solid brown overlay (rgba(59,36,24,0.55)) with NO gradients */}
        <div
          className="absolute inset-0"
          style={{ backgroundColor: 'rgba(59, 36, 24, 0.55)' }}
        />
      </div>

      {/* CONTENT GRID: Layer 2 (Middle, text) + Layer 3 (Front, 3D alternating cards) */}
      <div className="relative z-10 w-full max-w-[1240px] mx-auto px-6 sm:px-8 py-28 sm:py-32">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-14 items-center">
          {/* LAYER 2 (MIDDLE): Heading, paragraph, and two buttons */}
          <div
            className="lg:col-span-7 flex flex-col items-start will-change-transform"
            style={{
              transform: `translate3d(0, ${layer2TranslateY}px, 0)`,
              opacity: layer2Opacity,
            }}
          >
            {/* Small gold label: 14px minimum, normal case, normal letter spacing */}
            <span className="text-[14px] sm:text-[15px] font-semibold text-[#B8913B] mb-3">
              Fresh bakes every day
            </span>

            {/* Heading in sentence case, bold Montserrat, normal letter spacing */}
            <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-[1.14] text-balance">
              Cakes and pastries for every occasion
            </h1>

            {/* Paragraph in 17px to 18px body font */}
            <p className="mt-5 text-[17px] lg:text-[18px] text-white/90 leading-relaxed max-w-xl">
              Birthday cakes, wedding cakes, meat pies and more. Look through what we have, check the prices, and message us on WhatsApp when you are ready.
            </p>

            {/* Two buttons: "View Menu" gold and "Chat on WhatsApp" white outline */}
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <Link
                href="/menu"
                className="inline-flex items-center gap-2 px-7 py-3.5 bg-[#B8913B] hover:bg-[#a68030] text-white text-[16px] font-bold rounded-md shadow-md hover:shadow-lg transition-all"
              >
                <span>View Menu</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
              <a
                href={getWhatsAppLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-7 py-3.5 bg-transparent border-2 border-white hover:bg-white hover:text-[#3B2418] text-white text-[16px] font-bold rounded-md transition-all shadow-sm"
              >
                <WhatsAppIcon className="w-5 h-5 fill-current shrink-0" />
                <span>Chat on WhatsApp</span>
              </a>
            </div>
          </div>

          {/* LAYER 3 (FRONT): Group of 3 rounded photo cards shown in 3D that alternate on hover */}
          <div className="lg:col-span-5 relative flex items-center justify-center pt-4 lg:pt-0">
            {/* 3D Perspective container (1000px perspective, preserve-3d) */}
            <div
              className="relative w-full max-w-[420px] aspect-[4/5] perspective-1000 preserve-3d cursor-pointer"
              onMouseEnter={handleCardsMouseEnter}
              onMouseLeave={handleCardsMouseLeave}
              style={{
                perspective: '1000px',
                transformStyle: 'preserve-3d',
              }}
            >
              {/* Inner tilting gimbal wrapper responding smoothly to mouse on desktop */}
              <div
                className={`w-full h-full relative preserve-3d ${
                  !isCardGroupHovered && !prefersReducedMotion ? 'animate-float-1' : ''
                }`}
                style={{
                  transformStyle: 'preserve-3d',
                  transform:
                    isTouchDevice || prefersReducedMotion
                      ? 'none'
                      : `rotateX(${mouseTilt.x}deg) rotateY(${mouseTilt.y}deg)`,
                  transition: 'transform 0.22s cubic-bezier(0.16, 1, 0.3, 1)',
                }}
              >
                {/* BACKGROUND ACCENT CARD (Glazed Doughnuts): Deep depth background */}
                <div
                  className="absolute top-16 right-2 w-[58%] aspect-[4/5] rounded-2xl overflow-hidden shadow-xl border border-white/20 bg-white will-change-transform z-10 hidden sm:block pointer-events-none"
                  style={{
                    transform: `translate3d(0, ${card3ScrollY}px, 20px) rotate(8deg)`,
                    opacity: 0.65,
                    transition: 'transform 0.15s ease-out',
                  }}
                >
                  <div className="relative w-full h-full">
                    <Image
                      src="/images/pastry_glazed_doughnuts_1793143028523.jpg"
                      alt="Glazed Ring Doughnuts"
                      fill
                      className="object-cover"
                      sizes="(max-width: 768px) 50vw, 260px"
                    />
                    <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-[#3B2418]/90 via-[#3B2418]/40 to-transparent p-3.5">
                      <span className="text-[13px] font-semibold text-[#B8913B] block">
                        Fresh Bakes
                      </span>
                      <span className="font-heading text-[15px] font-bold text-white block">
                        Glazed Doughnuts
                      </span>
                    </div>
                  </div>
                </div>

                {/* PAIR CARD 0: Celebration Cakes / Vanilla Floral Cake */}
                <motion.div
                  role="button"
                  tabIndex={0}
                  aria-label="Vanilla Floral Cake, Celebration Cakes"
                  onClick={() => handleCardClick(0)}
                  onFocus={() => handleCardFocus(0)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      handleCardClick(0);
                    }
                  }}
                  animate={
                    activeCard === 0
                      ? {
                          // FRONT STATE: Larger, brighter, on top
                          x: 0,
                          y: 10 + card1ScrollY,
                          z: 90,
                          scale: 1,
                          rotateY: 0,
                          opacity: 1,
                          zIndex: 30,
                        }
                      : {
                          // BACK STATE: Slightly smaller, offset up and to side, dimmer
                          x: 55,
                          y: -35 + card1ScrollY,
                          z: 30,
                          scale: 0.88,
                          rotateY: 8,
                          opacity: 0.75,
                          zIndex: 15,
                        }
                  }
                  transition={springTransition}
                  className="absolute top-4 left-0 w-[68%] aspect-[4/5] rounded-2xl overflow-hidden shadow-2xl border border-white/30 bg-white will-change-transform focus:outline-none focus-visible:ring-3 focus-visible:ring-[#B8913B]"
                  style={{
                    transformStyle: 'preserve-3d',
                    backfaceVisibility: 'hidden',
                  }}
                >
                  <div className="relative w-full h-full">
                    <Image
                      src="/images/cake_vanilla_celebration_1793142929181.jpg"
                      alt="Celebration Cake"
                      fill
                      className="object-cover"
                      sizes="(max-width: 768px) 60vw, 300px"
                    />
                    <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-[#3B2418]/90 via-[#3B2418]/40 to-transparent p-4">
                      <span className="text-[13px] font-semibold text-[#B8913B] block">
                        Celebration Cakes
                      </span>
                      <span className="font-heading text-[16px] font-bold text-white block">
                        Vanilla Floral Cake
                      </span>
                    </div>
                  </div>
                </motion.div>

                {/* PAIR CARD 1: Savory Delights / Flaky Meat Pie */}
                <motion.div
                  role="button"
                  tabIndex={0}
                  aria-label="Flaky Meat Pie, Savory Delights"
                  onClick={() => handleCardClick(1)}
                  onFocus={() => handleCardFocus(1)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      handleCardClick(1);
                    }
                  }}
                  animate={
                    activeCard === 1
                      ? {
                          // FRONT STATE: Larger, brighter, on top
                          x: 0,
                          y: 10 + card2ScrollY,
                          z: 90,
                          scale: 1,
                          rotateY: 0,
                          opacity: 1,
                          zIndex: 30,
                        }
                      : {
                          // BACK STATE: Slightly smaller, offset up and to side, dimmer
                          x: -45,
                          y: -35 + card2ScrollY,
                          z: 30,
                          scale: 0.88,
                          rotateY: -8,
                          opacity: 0.75,
                          zIndex: 15,
                        }
                  }
                  transition={springTransition}
                  className="absolute bottom-2 right-2 w-[68%] aspect-[4/5] rounded-2xl overflow-hidden shadow-2xl border border-white/30 bg-white will-change-transform focus:outline-none focus-visible:ring-3 focus-visible:ring-[#B8913B]"
                  style={{
                    transformStyle: 'preserve-3d',
                    backfaceVisibility: 'hidden',
                  }}
                >
                  <div className="relative w-full h-full">
                    <Image
                      src="/images/pastry_flaky_meat_pie_1793142930485.jpg"
                      alt="Flaky Meat Pie"
                      fill
                      className="object-cover"
                      sizes="(max-width: 768px) 60vw, 300px"
                    />
                    <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-[#3B2418]/90 via-[#3B2418]/40 to-transparent p-4">
                      <span className="text-[13px] font-semibold text-[#B8913B] block">
                        Savory Delights
                      </span>
                      <span className="font-heading text-[16px] font-bold text-white block">
                        Flaky Meat Pie
                      </span>
                    </div>
                  </div>
                </motion.div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Small Animated "Scroll Down" Arrow at the bottom */}
      <button
        onClick={handleScrollDownClick}
        aria-label="Scroll to content"
        className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-1 text-white/80 hover:text-white transition-colors cursor-pointer group"
      >
        <span className="text-[13px] font-semibold">Scroll</span>
        <ChevronDown className="w-5 h-5 animate-bounce-slow text-[#B8913B] stroke-[2.5]" />
      </button>
    </section>
  );
}
