'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useBakeryStore, Product } from '@/lib/store';
import { ProductCard } from './ProductCard';
import { ProductModal } from './ProductModal';
import { ArrowRight } from 'lucide-react';

export function FeaturedProducts() {
  const { featuredProducts } = useBakeryStore();
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  if (featuredProducts.length === 0) return null;

  return (
    <section id="featured-section" className="py-16 sm:py-24 bg-white border-b border-[#3B2418]/10">
      <div className="max-w-[1240px] mx-auto px-6 sm:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-12">
          <div>
            <span className="text-[14px] sm:text-[15px] font-semibold text-[#B8913B] mb-1.5 block">
              Handpicked selections
            </span>
            <h2 className="font-heading text-3xl sm:text-4xl font-bold text-[#3B2418]">
              Our favourites
            </h2>
            <p className="mt-2 text-[17px] lg:text-[18px] text-[#6B4A3A]">
              A few of our popular cakes, pies, and morning bakes.
            </p>
          </div>

          <Link
            href="/menu"
            className="inline-flex items-center gap-2 text-[16px] font-bold text-[#B8913B] hover:text-[#3B2418] transition-colors group"
          >
            <span>View full menu</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        {/* Responsive Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {featuredProducts.slice(0, 6).map((product) => (
            <ProductCard
              key={product._id}
              product={product}
              onOpenDetails={(p) => setSelectedProduct(p)}
            />
          ))}
        </div>
      </div>

      <ProductModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
      />
    </section>
  );
}
