'use client';

import React from 'react';
import Link from 'next/link';
import { BAKERY_CONFIG, getWhatsAppLink, getCallLink } from '@/src/config';
import { Phone, Instagram } from 'lucide-react';
import { BrandWordmark } from './BrandWordmark';

function WhatsAppIcon({ className = 'w-4 h-4' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.472 14.382c-.301-.15-1.781-.878-2.056-.978-.276-.1-.476-.15-.676.15-.2.301-.776.978-.951 1.178-.175.201-.351.226-.652.076-.301-.15-1.272-.469-2.424-1.496-.896-.799-1.5-1.788-1.676-2.088-.176-.301-.019-.464.132-.614.136-.135.301-.351.451-.527.15-.175.2-.3.301-.501.1-.201.05-.376-.025-.526-.075-.15-.677-1.631-.927-2.233-.243-.586-.49-.506-.676-.516l-.576-.01c-.2 0-.526.075-.802.376-.275.301-1.052 1.028-1.052 2.508 0 1.48 1.077 2.909 1.227 3.109.15.201 2.12 3.238 5.137 4.542.717.31 1.277.496 1.713.635.72.23 1.375.197 1.892.12.576-.086 1.781-.728 2.032-1.431.25-.702.25-1.304.175-1.43-.075-.126-.275-.201-.576-.351zM12.04 2C6.516 2 2.025 6.49 2.025 12.015c0 1.956.564 3.784 1.542 5.334L2 22.025l4.825-1.523c1.487.917 3.23 1.442 5.215 1.442 5.525 0 10.015-4.49 10.015-10.015C22.055 6.49 17.565 2 12.04 2z" />
    </svg>
  );
}

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#3B2418] text-[#FAF6F0] py-16">
      <div className="max-w-[1240px] mx-auto px-6 sm:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 lg:gap-16">
          {/* Brand Info with two-line BrandWordmark in ivory */}
          <div className="md:col-span-5">
            <Link href="/" className="inline-block group" aria-label={BAKERY_CONFIG.brandName}>
              <BrandWordmark color="ivory" />
            </Link>
            <p className="mt-4 text-[16px] text-[#FAF6F0]/80 leading-relaxed max-w-sm">
              Cakes and pastries for every occasion. Look through what we have, check the prices, and message us on WhatsApp when you are ready.
            </p>
          </div>

          {/* Navigation */}
          <div className="md:col-span-3">
            <span className="text-[16px] font-bold text-[#FAF6F0] block mb-4">
              Navigation
            </span>
            <ul className="space-y-3 text-[16px] text-[#FAF6F0]/80">
              <li>
                <Link href="/" className="hover:text-[#B8913B] transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/menu" className="hover:text-[#B8913B] transition-colors">
                  Menu & Prices
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-[#B8913B] transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-[#B8913B] transition-colors">
                  Contact & Orders
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Details */}
          <div className="md:col-span-4">
            <span className="text-[16px] font-bold text-[#FAF6F0] block mb-4">
              Get in touch
            </span>
            <ul className="space-y-3.5 text-[16px] text-[#FAF6F0]/80">
              <li>
                <a
                  href={getWhatsAppLink()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2.5 hover:text-[#B8913B] transition-colors"
                >
                  <WhatsAppIcon className="w-4 h-4 fill-[#B8913B] shrink-0" />
                  <span>Chat on WhatsApp</span>
                </a>
              </li>
              <li>
                <a
                  href={getCallLink()}
                  className="inline-flex items-center gap-2.5 hover:text-[#B8913B] transition-colors"
                >
                  <Phone className="w-4 h-4 text-[#B8913B] shrink-0" />
                  <span>{BAKERY_CONFIG.phoneDisplay}</span>
                </a>
              </li>
              <li>
                <a
                  href={BAKERY_CONFIG.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2.5 hover:text-[#B8913B] transition-colors"
                >
                  <Instagram className="w-4 h-4 text-[#B8913B] shrink-0" />
                  <span>{BAKERY_CONFIG.instagramHandle}</span>
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-14 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-[14px] text-[#FAF6F0]/60">
          <div>
            &copy; {currentYear} {BAKERY_CONFIG.brandName}. All rights reserved.
          </div>

          <div>
            <Link
              href="/admin"
              className="text-[14px] text-[#FAF6F0]/40 hover:text-[#B8913B] transition-colors"
            >
              Admin Portal
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
