'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
import { useBakeryStore } from '@/lib/store';
import { BrandWordmark } from './BrandWordmark';

export function AdminLogin() {
  const router = useRouter();
  const { login, isAuthenticated, isAuthLoading } = useBakeryStore();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // If already authenticated as admin, redirect to /admin
  useEffect(() => {
    if (isAuthenticated) {
      router.push('/admin');
    }
  }, [isAuthenticated, router]);

  if (isAuthLoading) {
    return (
      <div className="min-h-screen bg-[#FAF6F0] flex items-center justify-center p-6">
        <span className="text-sm font-semibold text-[#6B4A3A]">
          Verifying session...
        </span>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      const res = await login(email, password);
      if (res.success) {
        router.push('/admin');
      } else {
        setError('Incorrect email or password.');
        setPassword('');
      }
    } catch {
      setError('Incorrect email or password.');
      setPassword('');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF6F0] flex flex-col justify-center py-16 px-6 sm:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="text-center flex flex-col items-center">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm font-semibold text-[#6B4A3A] hover:text-[#B8913B] mb-6 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to storefront</span>
          </Link>
          <BrandWordmark color="brown" className="items-center mb-2" />
          <h1 className="text-xl font-bold text-[#3B2418] mt-3 block">
            Administrator sign in
          </h1>
        </div>

        <div className="mt-8 bg-white py-8 px-6 sm:px-8 rounded-xl border border-[#3B2418]/15 shadow-sm">
          {error && (
            <div className="mb-6 p-3 bg-red-50 border border-red-300 text-red-900 text-sm rounded-md text-center">
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-bold text-[#3B2418] mb-1.5">
                Email
              </label>
              <input
                type="email"
                required
                autoComplete="username"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-[#FAF6F0] rounded-md border border-[#3B2418]/20 text-base text-[#3B2418] focus:outline-none focus:border-[#B8913B]"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-[#3B2418] mb-1.5">
                Password
              </label>
              <input
                type="password"
                required
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-[#FAF6F0] rounded-md border border-[#3B2418]/20 text-base text-[#3B2418] focus:outline-none focus:border-[#B8913B]"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-[#B8913B] hover:bg-[#a68030] text-white text-base font-bold rounded-md transition-colors disabled:opacity-50"
            >
              <span>{isSubmitting ? 'Signing In...' : 'Sign In'}</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
