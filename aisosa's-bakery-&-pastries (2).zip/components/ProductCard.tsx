'use client';

import React from 'react';
import Image from 'next/image';
import { Product } from '@/lib/store';
import { formatNaira } from '@/lib/utils';
import { getWhatsAppLink } from '@/src/config';

function WhatsAppIcon({ className = 'w-4 h-4' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.472 14.382c-.301-.15-1.781-.878-2.056-.978-.276-.1-.476-.15-.676.15-.2.301-.776.978-.951 1.178-.175.201-.351.226-.652.076-.301-.15-1.272-.469-2.424-1.496-.896-.799-1.5-1.788-1.676-2.088-.176-.301-.019-.464.132-.614.136-.135.301-.351.451-.527.15-.175.2-.3.301-.501.1-.201.05-.376-.025-.526-.075-.15-.677-1.631-.927-2.233-.243-.586-.49-.506-.676-.516l-.576-.01c-.2 0-.526.075-.802.376-.275.301-1.052 1.028-1.052 2.508 0 1.48 1.077 2.909 1.227 3.109.15.201 2.12 3.238 5.137 4.542.717.31 1.277.496 1.713.635.72.23 1.375.197 1.892.12.576-.086 1.781-.728 2.032-1.431.25-.702.25-1.304.175-1.43-.075-.126-.275-.201-.576-.351zM12.04 2C6.516 2 2.025 6.49 2.025 12.015c0 1.956.564 3.784 1.542 5.334L2 22.025l4.825-1.523c1.487.917 3.23 1.442 5.215 1.442 5.525 0 10.015-4.49 10.015-10.015C22.055 6.49 17.565 2 12.04 2z" />
    </svg>
  );
}

interface ProductCardProps {
  product: Product;
  onOpenDetails: (product: Product) => void;
}

export function ProductCard({ product, onOpenDetails }: ProductCardProps) {
  const enquiryMessage = `Hello Aisosa's Bakery, I would like to ask about ${product.name} (${formatNaira(product.price)}).`;

  return (
    <article
      onClick={() => onOpenDetails(product)}
      className="group cursor-pointer bg-white rounded-xl border border-[#3B2418]/10 overflow-hidden hover:border-[#B8913B]/50 hover:shadow-lg transition-all duration-300 flex flex-col"
    >
      {/* Photo on top with rounded corners */}
      <div className="relative w-full aspect-[4/3] bg-[#FAF6F0] overflow-hidden">
        {product.imageUrl ? (
          <Image
            src={product.imageUrl}
            alt={product.name}
            fill
            className="object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-[#FAF6F0] text-[#6B4A3A] font-semibold text-[16px]">
            Aisosa&apos;s Bakery
          </div>
        )}

        {!product.isAvailable && (
          <div className="absolute top-3 right-3 bg-[#3B2418]/90 text-white text-[13px] font-medium px-3 py-1 rounded-md shadow-sm">
            Order ahead only
          </div>
        )}
      </div>

      {/* Product Name, Category, Price */}
      <div className="p-6 flex-1 flex flex-col justify-between gap-4">
        <div>
          <span className="text-[14px] font-semibold text-[#B8913B] block">
            {product.categoryName || 'Bakery Item'}
          </span>
          <h3 className="font-heading text-[19px] font-bold text-[#3B2418] mt-1.5 group-hover:text-[#B8913B] transition-colors leading-snug">
            {product.name}
          </h3>
          <p className="mt-2 text-[16px] text-[#6B4A3A] line-clamp-2 leading-relaxed">
            {product.description}
          </p>
        </div>

        <div className="pt-4 flex items-center justify-between border-t border-[#3B2418]/10">
          <span className="text-[18px] font-bold text-[#3B2418] tabular-nums">
            {formatNaira(product.price)}
          </span>

          <a
            href={getWhatsAppLink(enquiryMessage)}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
            className="inline-flex items-center gap-1.5 text-[14px] font-bold text-[#B8913B] hover:text-[#3B2418] transition-colors"
          >
            <WhatsAppIcon className="w-4 h-4 fill-current shrink-0" />
            <span>Ask on WhatsApp</span>
          </a>
        </div>
      </div>
    </article>
  );
}
