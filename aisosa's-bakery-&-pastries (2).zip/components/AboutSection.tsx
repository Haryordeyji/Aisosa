'use client';

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';

export function AboutSection() {
  return (
    <section className="py-16 sm:py-24 bg-[#FAF6F0] border-b border-[#3B2418]/10">
      <div className="max-w-[1240px] mx-auto px-6 sm:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 lg:gap-16 items-center">
          {/* Photo */}
          <div className="md:col-span-5 relative">
            <div className="relative w-full aspect-[4/3] rounded-2xl overflow-hidden bg-white shadow-md border border-[#3B2418]/10">
              <Image
                src="/images/pastry_flaky_meat_pie_1793142930485.jpg"
                alt="Freshly baked pies and pastries"
                fill
                className="object-cover"
                sizes="(max-width: 768px) 100vw, 550px"
              />
            </div>
          </div>

          {/* Text */}
          <div className="md:col-span-7 flex flex-col items-start">
            <span className="text-[14px] sm:text-[15px] font-semibold text-[#B8913B] mb-2 block">
              Our story and promise
            </span>

            <h2 className="font-heading text-3xl sm:text-4xl font-bold text-[#3B2418] leading-tight">
              About Aisosa&apos;s Bakery
            </h2>

            <p className="mt-4 text-[17px] lg:text-[18px] text-[#6B4A3A] leading-relaxed">
              We bake cakes and pastries for birthdays, weddings, and everyday treats. Our menu shows every price upfront so you always know what to expect.
            </p>

            <p className="mt-3 text-[17px] lg:text-[18px] text-[#6B4A3A] leading-relaxed">
              Orders are not taken directly on this website. Please message us on WhatsApp or call to ask what is available for your date.
            </p>

            <div className="mt-7">
              <Link
                href="/about"
                className="inline-flex items-center gap-2 text-[16px] font-bold text-[#B8913B] hover:text-[#3B2418] transition-colors group"
              >
                <span>Learn more about how we work</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
