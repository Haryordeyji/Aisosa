'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Menu, X } from 'lucide-react';
import { BAKERY_CONFIG, getWhatsAppLink } from '@/src/config';
import { BrandWordmark } from './BrandWordmark';

function WhatsAppIcon({ className = 'w-4 h-4' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.472 14.382c-.301-.15-1.781-.878-2.056-.978-.276-.1-.476-.15-.676.15-.2.301-.776.978-.951 1.178-.175.201-.351.226-.652.076-.301-.15-1.272-.469-2.424-1.496-.896-.799-1.5-1.788-1.676-2.088-.176-.301-.019-.464.132-.614.136-.135.301-.351.451-.527.15-.175.2-.3.301-.501.1-.201.05-.376-.025-.526-.075-.15-.677-1.631-.927-2.233-.243-.586-.49-.506-.676-.516l-.576-.01c-.2 0-.526.075-.802.376-.275.301-1.052 1.028-1.052 2.508 0 1.48 1.077 2.909 1.227 3.109.15.201 2.12 3.238 5.137 4.542.717.31 1.277.496 1.713.635.72.23 1.375.197 1.892.12.576-.086 1.781-.728 2.032-1.431.25-.702.25-1.304.175-1.43-.075-.126-.275-.201-.576-.351zM12.04 2C6.516 2 2.025 6.49 2.025 12.015c0 1.956.564 3.784 1.542 5.334L2 22.025l4.825-1.523c1.487.917 3.23 1.442 5.215 1.442 5.525 0 10.015-4.49 10.015-10.015C22.055 6.49 17.565 2 12.04 2z" />
    </svg>
  );
}

export function Navbar() {
  const [scrollY, setScrollY] = useState(0);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const pathname = usePathname();

  const isHome = pathname === '/' || pathname === '';

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      setScrollY(currentScrollY);

      const totalScroll =
        document.documentElement.scrollHeight - window.innerHeight;
      if (totalScroll > 0) {
        setScrollProgress((currentScrollY / totalScroll) * 100);
      } else {
        setScrollProgress(0);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // On inner pages the header is solid from the start. On home page it turns solid after 40px
  const isSolid = !isHome || scrollY > 40;

  const navLinks = [
    { label: 'Home', href: '/' },
    { label: 'Menu & Prices', href: '/menu' },
    { label: 'About Us', href: '/about' },
    { label: 'Contact', href: '/contact' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ease-out ${
        isSolid
          ? 'bg-[#FAF6F0] text-[#3B2418] shadow-sm border-b border-[#3B2418]/10'
          : 'bg-transparent text-white'
      }`}
    >
      <div
        className={`max-w-[1240px] mx-auto px-6 sm:px-8 flex items-center justify-between gap-6 transition-all duration-300 ${
          isSolid ? 'h-[68px]' : 'h-[88px]'
        }`}
      >
        {/* Left: Two-line brand wordmark with Dancing Script and Montserrat */}
        <Link
          href="/"
          className="flex items-center gap-2 group shrink-0 py-1"
          aria-label={BAKERY_CONFIG.brandName}
        >
          <BrandWordmark isSolid={isSolid} isShrunk={isSolid} />
        </Link>

        {/* Center / Right Links with sliding gold underline on hover and active state */}
        <nav className="hidden md:flex items-center gap-8 text-[16px] font-semibold">
          {navLinks.map((link) => {
            const isActive =
              link.href === '/'
                ? pathname === '/' || pathname === ''
                : pathname === link.href || pathname.startsWith(link.href + '/');

            return (
              <Link
                key={link.href}
                href={link.href}
                className={`relative py-1.5 transition-colors group ${
                  isActive
                    ? 'text-[#B8913B] font-bold'
                    : isSolid
                    ? 'text-[#3B2418] hover:text-[#B8913B]'
                    : 'text-white hover:text-[#B8913B]'
                }`}
              >
                {link.label}
                <span
                  className={`absolute bottom-0 left-0 h-[2px] bg-[#B8913B] transition-all duration-300 ease-out ${
                    isActive ? 'w-full' : 'w-0 group-hover:w-full'
                  }`}
                />
              </Link>
            );
          })}
        </nav>

        {/* Right: Gold "Chat on WhatsApp" Button with small icon that lifts on hover */}
        <div className="hidden md:flex items-center shrink-0">
          <a
            href={getWhatsAppLink()}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#B8913B] hover:bg-[#a68030] text-white text-sm font-bold rounded-md shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200"
          >
            <WhatsAppIcon className="w-4 h-4 fill-current shrink-0" />
            <span>Chat on WhatsApp</span>
          </a>
        </div>

        {/* Mobile Hamburger Button */}
        <div className="flex md:hidden items-center">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className={`p-2 transition-colors ${
              isSolid
                ? 'text-[#3B2418] hover:text-[#B8913B]'
                : 'text-white hover:text-[#B8913B]'
            }`}
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? (
              <X className="w-7 h-7 stroke-[2]" />
            ) : (
              <Menu className="w-7 h-7 stroke-[2]" />
            )}
          </button>
        </div>
      </div>

      {/* Thin Gold Progress Bar Under Header */}
      <div
        className="absolute bottom-0 left-0 h-[2px] bg-[#B8913B] transition-all duration-100 ease-out pointer-events-none"
        style={{ width: `${scrollProgress}%` }}
      />

      {/* Mobile Drawer sliding down smoothly */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-[#3B2418]/15 bg-[#FAF6F0] text-[#3B2418] px-6 py-6 shadow-xl animate-in slide-in-from-top-4 duration-300">
          <nav className="flex flex-col gap-2 text-lg font-bold">
            {navLinks.map((link) => {
              const isActive =
                link.href === '/'
                  ? pathname === '/' || pathname === ''
                  : pathname === link.href || pathname.startsWith(link.href + '/');
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`py-3 px-2 border-b border-[#3B2418]/10 transition-colors ${
                    isActive ? 'text-[#B8913B]' : 'text-[#3B2418] hover:text-[#B8913B]'
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
            <div className="pt-4">
              <a
                href={getWhatsAppLink()}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full flex items-center justify-center gap-2 py-3.5 bg-[#B8913B] hover:bg-[#a68030] text-white text-base font-bold rounded-md shadow-sm transition-all"
              >
                <WhatsAppIcon className="w-5 h-5 fill-current shrink-0" />
                <span>Chat on WhatsApp</span>
              </a>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
