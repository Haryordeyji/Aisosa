'use client';

import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { useBakeryStore, Product } from '@/lib/store';
import { ProductCard } from './ProductCard';
import { ProductModal } from './ProductModal';

export function MenuCatalog() {
  const {
    categories,
    publicProducts,
    selectedCategory,
    setSelectedCategory,
    searchQuery,
    setSearchQuery,
    showUnavailable,
    setShowUnavailable,
    isLoading,
  } = useBakeryStore();

  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  return (
    <div className="min-h-screen bg-[#FAF6F0] pt-24 pb-20 sm:pt-28 sm:pb-24">
      <div className="max-w-[1240px] mx-auto px-6 sm:px-8">
        {/* Header */}
        <div className="max-w-2xl mb-12">
          <span className="text-[14px] sm:text-[15px] font-semibold text-[#B8913B] mb-2 block">
            Fresh selections and direct pricing
          </span>
          <h1 className="font-heading text-4xl sm:text-5xl font-bold text-[#3B2418]">
            Our menu
          </h1>
          <p className="mt-3 text-[17px] lg:text-[18px] text-[#6B4A3A] leading-relaxed">
            Browse all our cakes and pastries below. Check prices, or search by name. When you find what you like, message us on WhatsApp to order.
          </p>
        </div>

        {/* Filter & Search Bar */}
        <div className="bg-white p-6 rounded-2xl border border-[#3B2418]/10 shadow-sm mb-12 space-y-6">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
            {/* Search Input */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#6B4A3A]/60" />
              <input
                type="text"
                placeholder="Search cakes, meat pies, rolls..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-12 py-2.5 bg-[#FAF6F0] rounded-lg border border-[#3B2418]/15 text-[15px] text-[#3B2418] placeholder:text-[#6B4A3A]/60 focus:outline-none focus:border-[#B8913B]"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[13px] font-bold text-[#6B4A3A] hover:text-[#3B2418]"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Toggle Unavailable */}
            <label className="flex items-center gap-2.5 text-[15px] font-semibold text-[#3B2418] cursor-pointer select-none">
              <input
                type="checkbox"
                checked={showUnavailable}
                onChange={(e) => setShowUnavailable(e.target.checked)}
                className="w-4 h-4 rounded text-[#B8913B] accent-[#B8913B]"
              />
              <span>Include order-ahead bakes</span>
            </label>
          </div>

          {/* Category Tabs */}
          <div className="pt-4 border-t border-[#3B2418]/10 flex items-center gap-2.5 overflow-x-auto pb-1 scrollbar-none">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-4 py-2.5 rounded-lg text-[15px] font-bold whitespace-nowrap transition-all ${
                selectedCategory === 'all'
                  ? 'bg-[#3B2418] text-white shadow-sm'
                  : 'bg-[#FAF6F0] text-[#3B2418] hover:bg-[#3B2418]/10'
              }`}
            >
              All items
            </button>
            {categories.map((cat) => {
              const isSelected = selectedCategory === cat._id;
              return (
                <button
                  key={cat._id}
                  onClick={() => setSelectedCategory(cat._id)}
                  className={`px-4 py-2.5 rounded-lg text-[15px] font-bold whitespace-nowrap transition-all ${
                    isSelected
                      ? 'bg-[#3B2418] text-white shadow-sm'
                      : 'bg-[#FAF6F0] text-[#3B2418] hover:bg-[#3B2418]/10'
                  }`}
                >
                  {cat.name}
                </button>
              );
            })}
          </div>
        </div>

        {/* Empty State */}
        {!isLoading && publicProducts.length === 0 && (
          <div className="bg-white rounded-2xl border border-[#3B2418]/10 p-12 text-center max-w-md mx-auto">
            <h3 className="font-heading text-2xl font-bold text-[#3B2418]">No bakes found</h3>
            <p className="mt-2 text-[16px] text-[#6B4A3A]">
              We could not find any items matching your search.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
              }}
              className="mt-5 px-6 py-2.5 bg-[#B8913B] text-white text-[15px] font-bold rounded-md hover:bg-[#a68030]"
            >
              Reset filters
            </button>
          </div>
        )}

        {/* Product Grid */}
        {!isLoading && publicProducts.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {publicProducts.map((product) => (
              <ProductCard
                key={product._id}
                product={product}
                onOpenDetails={(p) => setSelectedProduct(p)}
              />
            ))}
          </div>
        )}
      </div>

      <ProductModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
      />
    </div>
  );
}
