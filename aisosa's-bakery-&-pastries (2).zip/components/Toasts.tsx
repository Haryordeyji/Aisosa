'use client';

import React from 'react';
import { useBakeryStore } from '@/lib/store';
import { Check, AlertCircle, Info, X } from 'lucide-react';

export function ToastContainer() {
  const { toasts, removeToast } = useBakeryStore();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-6 right-6 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
      {toasts.map((toast) => {
        const isSuccess = toast.type === 'success';
        const isError = toast.type === 'error';

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-start gap-3 p-4 bg-[#3B2418] text-[#FAF6F0] rounded-md border ${
              isSuccess
                ? 'border-[#B8913B]'
                : isError
                ? 'border-red-400/60'
                : 'border-[#B8913B]/40'
            } shadow-md transition-all`}
          >
            <div className="shrink-0 mt-0.5">
              {isSuccess && <Check className="w-4 h-4 text-[#B8913B] stroke-[1.5]" />}
              {isError && <AlertCircle className="w-4 h-4 text-red-300 stroke-[1.5]" />}
              {!isSuccess && !isError && <Info className="w-4 h-4 text-[#B8913B] stroke-[1.5]" />}
            </div>
            <div className="flex-1 text-sm font-medium leading-relaxed">
              {toast.message}
            </div>
            <button
              onClick={() => removeToast(toast.id)}
              className="shrink-0 text-[#FAF6F0]/60 hover:text-[#FAF6F0] transition-colors p-0.5"
              aria-label="Dismiss notification"
            >
              <X className="w-3.5 h-3.5 stroke-[1.5]" />
            </button>
          </div>
        );
      })}
    </div>
  );
}
