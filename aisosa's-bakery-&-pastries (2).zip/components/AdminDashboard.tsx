'use client';

import React, { useState, useRef } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import {
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  LogOut,
  Upload,
  FolderTree,
  RotateCcw,
  ExternalLink,
  Search,
  CheckCircle2,
  AlertTriangle,
  Eye,
  SlidersHorizontal,
} from 'lucide-react';
import { useBakeryStore, Product, Category } from '@/lib/store';
import { formatNaira, formatDate } from '@/lib/utils';
import { BAKERY_CONFIG } from '@/src/config';

export function AdminDashboard() {
  const router = useRouter();
  const {
    products,
    categories,
    isAuthenticated,
    isAuthLoading,
    logout,
    addProduct,
    updateProduct,
    quickUpdatePrice,
    deleteProduct,
    addCategory,
    updateCategory,
    deleteCategory,
    seedSampleProducts,
    generateUploadUrl,
    addToast,
  } = useBakeryStore();

  // Search & Filter in Admin
  const [filterQuery, setFilterQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');

  // Inline Price Editing State
  const [editingPriceId, setEditingPriceId] = useState<string | null>(null);
  const [tempPriceValue, setTempPriceValue] = useState<string>('');

  // Modals
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);

  // Form State for Product Add/Edit
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: 0,
    categoryId: '',
    imageUrl: '',
    imageStorageId: undefined as string | undefined,
    isAvailable: true,
    isFeatured: false,
  });
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [isSavingProduct, setIsSavingProduct] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Category Manager State
  const [newCategoryName, setNewCategoryName] = useState('');
  const [editingCatId, setEditingCatId] = useState<string | null>(null);
  const [editingCatName, setEditingCatName] = useState('');

  // Protect Admin Access: loading state while resolving
  if (isAuthLoading) {
    return (
      <div className="min-h-screen bg-[#FAF6F0] flex items-center justify-center p-6">
        <span className="text-xs    text-[#6B4A3A]">
          Verifying session...
        </span>
      </div>
    );
  }

  // Protect Admin Access: redirect to login if unauthenticated
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#FAF6F0] flex items-center justify-center p-6">
        <div className="bg-[#FFFFFF] p-10 border border-[#B8913B]/30 shadow-md text-center max-w-md w-full">
          <AlertTriangle className="w-10 h-10 text-[#B8913B] stroke-[1.5] mx-auto mb-4" />
          <h2 className=" text-2xl font-normal text-[#3B2418]">Administrator Portal Protected</h2>
          <p className="mt-2 text-xs text-[#6B4A3A]">
            Please sign in with your administrator account to manage bakery inventory.
          </p>
          <button
            onClick={() => router.push('/admin/login')}
            className="mt-6 w-full py-3.5 bg-[#B8913B] hover:bg-[#a68030] text-white font-medium text-xs    transition-colors"
          >
            Sign In with Administrator Account
          </button>
        </div>
      </div>
    );
  }

  // Open Modal for Create
  const handleOpenCreateModal = () => {
    setEditingProduct(null);
    setFormData({
      name: '',
      description: '',
      price: 15000,
      categoryId: categories[0]?._id || '',
      imageUrl: '',
      imageStorageId: undefined,
      isAvailable: true,
      isFeatured: false,
    });
    setImagePreview(null);
    setSelectedFile(null);
    setIsProductModalOpen(true);
  };

  // Open Modal for Edit
  const handleOpenEditModal = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      description: product.description,
      price: product.price,
      categoryId: product.categoryId,
      imageUrl: product.imageUrl || '',
      imageStorageId: product.imageStorageId,
      isAvailable: product.isAvailable,
      isFeatured: product.isFeatured,
    });
    setImagePreview(product.imageUrl || null);
    setSelectedFile(null);
    setIsProductModalOpen(true);
  };

  // Handle File Upload with 5MB limit and format validation
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate type
    const validTypes = ['image/jpeg', 'image/png', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      addToast('Invalid file format. Please upload JPG, PNG, or WebP.', 'error');
      return;
    }

    // Validate size (5MB = 5 * 1024 * 1024 bytes)
    if (file.size > 5 * 1024 * 1024) {
      addToast('Image exceeds 5MB size limit.', 'error');
      return;
    }

    setSelectedFile(file);
    const localPreviewUrl = URL.createObjectURL(file);
    setImagePreview(localPreviewUrl);
    addToast('Image selected and preview ready.', 'info');
  };

  // Save Product (Create or Edit) with Convex Storage upload
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      addToast('Product name is required.', 'error');
      return;
    }
    if (formData.price <= 0) {
      addToast('Price must be greater than zero.', 'error');
      return;
    }
    if (!formData.categoryId) {
      addToast('Please select a category.', 'error');
      return;
    }

    setIsSavingProduct(true);
    try {
      let finalStorageId = formData.imageStorageId;
      let finalImageUrl: string | undefined = formData.imageUrl || undefined;

      // If a new local file was selected, upload it to Convex Storage
      if (selectedFile) {
        setIsUploadingImage(true);
        try {
          const uploadUrl = await generateUploadUrl();
          const uploadRes = await fetch(uploadUrl, {
            method: 'POST',
            headers: { 'Content-Type': selectedFile.type },
            body: selectedFile,
          });

          if (!uploadRes.ok) {
            throw new Error('Failed to upload image file to storage.');
          }

          const { storageId } = await uploadRes.json();
          finalStorageId = storageId;
          finalImageUrl = undefined; // StorageId takes precedence
        } finally {
          setIsUploadingImage(false);
        }
      }

      if (editingProduct) {
        await updateProduct(editingProduct._id, {
          name: formData.name.trim(),
          description: formData.description.trim(),
          price: Number(formData.price),
          categoryId: formData.categoryId,
          imageUrl: finalImageUrl || null,
          imageStorageId: finalStorageId,
          isAvailable: formData.isAvailable,
          isFeatured: formData.isFeatured,
        });
      } else {
        await addProduct({
          name: formData.name.trim(),
          description: formData.description.trim(),
          price: Number(formData.price),
          categoryId: formData.categoryId,
          imageUrl: finalImageUrl || null,
          imageStorageId: finalStorageId,
          isAvailable: formData.isAvailable,
          isFeatured: formData.isFeatured,
        });
      }
      setIsProductModalOpen(false);
      setSelectedFile(null);
    } catch (err: any) {
      addToast(err?.message || 'Error saving product.', 'error');
    } finally {
      setIsSavingProduct(false);
    }
  };

  // Inline Price Edit Handlers
  const startInlineEdit = (prod: Product) => {
    setEditingPriceId(prod._id);
    setTempPriceValue(prod.price.toString());
  };

  const saveInlineEdit = async (id: string) => {
    const val = Number(tempPriceValue);
    if (isNaN(val) || val <= 0) {
      addToast('Please enter a valid price amount.', 'error');
      return;
    }
    await quickUpdatePrice(id, val);
    setEditingPriceId(null);
  };

  const cancelInlineEdit = () => {
    setEditingPriceId(null);
    setTempPriceValue('');
  };

  // Delete Action
  const confirmDeleteProduct = async () => {
    if (!productToDelete) return;
    await deleteProduct(productToDelete._id);
    setIsDeleteModalOpen(false);
    setProductToDelete(null);
  };

  // Filtered List
  const filteredProducts = products.filter((p) => {
    if (filterCategory !== 'all' && p.categoryId !== filterCategory) return false;
    if (filterQuery.trim()) {
      const q = filterQuery.toLowerCase();
      return p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q);
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-[#FAF7F2] pb-24">
      {/* Top Admin Navbar */}
      <header className="bg-[#3E2723] text-white border-b border-[#C9A227]/30 sticky top-0 z-20 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Link href="/" className="flex flex-col">
              <span className=" text-lg font-bold   text-white hover:text-[#C9A227] transition-colors">
                {BAKERY_CONFIG.shortName}
              </span>
              <span className="text-[10px]    text-[#C9A227]">
                Admin Dashboard
              </span>
            </Link>
          </div>

          <div className="flex items-center gap-3">
            <Link
              href="/"
              target="_blank"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold text-[#FDFBF7] transition-colors border border-white/10"
            >
              <ExternalLink className="w-3.5 h-3.5 text-[#C9A227]" />
              <span className="hidden sm:inline">View Public Store</span>
            </Link>

            <button
              onClick={() => {
                logout();
                router.push('/');
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900 text-rose-200 text-xs font-semibold border border-rose-800/40 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        {/* Metric Badges */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          <div className="bg-white p-5 rounded-xl border border-[#C9A227]/20 shadow-sm">
            <span className="text-xs    text-[#5D4037] font-semibold block">
              Total Products
            </span>
            <span className=" text-2xl sm:text-3xl font-bold text-[#3E2723] tabular-nums mt-1 block">
              {products.length}
            </span>
          </div>

          <div className="bg-white p-5 rounded-xl border border-[#C9A227]/20 shadow-sm">
            <span className="text-xs    text-[#5D4037] font-semibold block">
              Available Items
            </span>
            <span className=" text-2xl sm:text-3xl font-bold text-emerald-800 tabular-nums mt-1 block">
              {products.filter((p) => p.isAvailable).length}
            </span>
          </div>

          <div className="bg-white p-5 rounded-xl border border-[#C9A227]/20 shadow-sm">
            <span className="text-xs    text-[#5D4037] font-semibold block">
              Featured on Home
            </span>
            <span className=" text-2xl sm:text-3xl font-bold text-[#B8860B] tabular-nums mt-1 block">
              {products.filter((p) => p.isFeatured).length}
            </span>
          </div>

          <div className="bg-white p-5 rounded-xl border border-[#C9A227]/20 shadow-sm">
            <span className="text-xs    text-[#5D4037] font-semibold block">
              Categories
            </span>
            <span className=" text-2xl sm:text-3xl font-bold text-[#3E2723] tabular-nums mt-1 block">
              {categories.length}
            </span>
          </div>
        </div>

        {/* Action Bar */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-[#C9A227]/25 shadow-sm mb-6 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
          {/* Search & Category Filter */}
          <div className="flex flex-1 flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5D4037]/60" />
              <input
                type="text"
                placeholder="Search catalog by name..."
                value={filterQuery}
                onChange={(e) => setFilterQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-lg border border-[#C9A227]/30 bg-[#FAF7F2]/50 text-xs text-[#3E2723] focus:outline-none focus:ring-1 focus:ring-[#C9A227]"
              />
            </div>

            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="py-2 px-3 rounded-lg border border-[#C9A227]/30 bg-[#FAF7F2]/50 text-xs text-[#3E2723] focus:outline-none focus:ring-1 focus:ring-[#C9A227]"
            >
              <option value="all">All Categories</option>
              {categories.map((c) => (
                <option key={c._id} value={c._id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => setIsCategoryModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#FAF7F2] hover:bg-[#F4EFEA] text-[#3E2723] text-xs font-semibold border border-[#C9A227]/40 transition-colors"
            >
              <FolderTree className="w-3.5 h-3.5 text-[#C9A227]" />
              <span>Manage Categories</span>
            </button>

            <button
              onClick={seedSampleProducts}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#FAF7F2] hover:bg-[#F4EFEA] text-[#3E2723] text-xs font-semibold border border-[#C9A227]/40 transition-colors"
              title="Add sample bakery items"
            >
              <RotateCcw className="w-3.5 h-3.5 text-[#C9A227]" />
              <span className="hidden sm:inline">Add Sample Items</span>
            </button>

            <button
              onClick={handleOpenCreateModal}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#3E2723] hover:bg-[#271612] text-white text-xs font-semibold shadow-sm transition-all"
            >
              <Plus className="w-4 h-4 text-[#C9A227]" />
              <span>Add Product</span>
            </button>
          </div>
        </div>

        {/* Products Table */}
        <div className="bg-white rounded-2xl border border-[#C9A227]/25 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#FAF7F2] border-b border-[#C9A227]/20 text-[11px] font-semibold    text-[#5D4037]">
                  <th className="py-3.5 px-4">Item</th>
                  <th className="py-3.5 px-4">Category</th>
                  <th className="py-3.5 px-4">
                    Price (₦) <span className="text-[10px] lowercase text-[#C9A227]">(inline edit)</span>
                  </th>
                  <th className="py-3.5 px-4 text-center">Status</th>
                  <th className="py-3.5 px-4 text-center">Featured</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#C9A227]/10 text-xs">
                {filteredProducts.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-[#5D4037]">
                      No products found. Click &quot;Add Product&quot; to create one.
                    </td>
                  </tr>
                ) : (
                  filteredProducts.map((product) => {
                    const isEditingThisPrice = editingPriceId === product._id;

                    return (
                      <tr key={product._id} className="hover:bg-[#FAF7F2]/60 transition-colors">
                        {/* Image & Name */}
                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-3">
                            <div className="relative w-12 h-12 rounded-lg overflow-hidden bg-[#FAF7F2] border border-[#C9A227]/30 shrink-0">
                              {product.imageUrl ? (
                                <Image
                                  src={product.imageUrl}
                                  alt={product.name}
                                  fill
                                  className="object-cover"
                                  sizes="48px"
                                  referrerPolicy="no-referrer"
                                />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center text-[10px] font-bold text-[#C9A227]">
                                  AB
                                </div>
                              )}
                            </div>
                            <div className="max-w-xs">
                              <span className=" font-bold text-sm text-[#3E2723] block leading-snug">
                                {product.name}
                              </span>
                              <span className="text-[11px] text-[#5D4037] line-clamp-1 mt-0.5">
                                {product.description}
                              </span>
                            </div>
                          </div>
                        </td>

                        {/* Category */}
                        <td className="py-3.5 px-4 text-[#5D4037] font-medium whitespace-nowrap">
                          {product.categoryName || 'Unassigned'}
                        </td>

                        {/* Quick Inline Price Edit */}
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          {isEditingThisPrice ? (
                            <div className="flex items-center gap-1.5">
                              <span className="text-[#3E2723] font-bold">₦</span>
                              <input
                                type="number"
                                autoFocus
                                value={tempPriceValue}
                                onChange={(e) => setTempPriceValue(e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') saveInlineEdit(product._id);
                                  if (e.key === 'Escape') cancelInlineEdit();
                                }}
                                className="w-24 px-2 py-1 rounded border border-[#C9A227] text-xs font-bold text-[#3E2723] focus:outline-none"
                              />
                              <button
                                onClick={() => saveInlineEdit(product._id)}
                                className="p-1 rounded bg-emerald-600 text-white hover:bg-emerald-700"
                                title="Save price"
                              >
                                <Check className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={cancelInlineEdit}
                                className="p-1 rounded bg-slate-300 text-slate-700 hover:bg-slate-400"
                                title="Cancel"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => startInlineEdit(product)}
                              className="group flex items-center gap-1.5 hover:bg-[#FAF7F2] px-2 py-1 rounded transition-colors text-left"
                              title="Click to quickly edit price"
                            >
                              <span className=" font-bold text-sm text-[#3E2723] tabular-nums">
                                {formatNaira(product.price)}
                              </span>
                              <Edit2 className="w-3 h-3 text-[#C9A227] opacity-0 group-hover:opacity-100 transition-opacity" />
                            </button>
                          )}
                        </td>

                        {/* Available Toggle */}
                        <td className="py-3.5 px-4 text-center whitespace-nowrap">
                          <button
                            onClick={() =>
                              updateProduct(product._id, { isAvailable: !product.isAvailable })
                            }
                            className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors ${
                              product.isAvailable
                                ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                                : 'bg-stone-200 text-stone-700 hover:bg-stone-300'
                            }`}
                          >
                            {product.isAvailable ? 'In Stock' : 'Unavailable'}
                          </button>
                        </td>

                        {/* Featured Toggle */}
                        <td className="py-3.5 px-4 text-center whitespace-nowrap">
                          <button
                            onClick={() =>
                              updateProduct(product._id, { isFeatured: !product.isFeatured })
                            }
                            className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors ${
                              product.isFeatured
                                ? 'bg-amber-100 text-amber-900 border border-amber-300 hover:bg-amber-200'
                                : 'text-stone-400 hover:text-stone-600'
                            }`}
                          >
                            {product.isFeatured ? 'Featured' : 'Standard'}
                          </button>
                        </td>

                        {/* Actions */}
                        <td className="py-3.5 px-4 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => handleOpenEditModal(product)}
                              className="p-1.5 rounded-lg text-[#5D4037] hover:text-[#3E2723] hover:bg-[#FAF7F2] transition-colors"
                              title="Edit all fields"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => {
                                setProductToDelete(product);
                                setIsDeleteModalOpen(true);
                              }}
                              className="p-1.5 rounded-lg text-rose-600 hover:text-rose-800 hover:bg-rose-50 transition-colors"
                              title="Delete product"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      {/* Product Add / Edit Modal */}
      {isProductModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div
            onClick={() => setIsProductModalOpen(false)}
            className="fixed inset-0 bg-[#271612]/70 backdrop-blur-sm"
          />

          <div className="relative w-full max-w-xl bg-white rounded-2xl border border-[#C9A227]/40 shadow-2xl p-6 sm:p-8 z-10 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-[#C9A227]/20">
              <h2 className=" text-xl sm:text-2xl font-bold text-[#3E2723]">
                {editingProduct ? 'Edit Bakery Product' : 'Add New Bakery Product'}
              </h2>
              <button
                onClick={() => setIsProductModalOpen(false)}
                className="text-[#5D4037] hover:text-[#3E2723]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="mt-6 space-y-4">
              {/* Product Name */}
              <div>
                <label className="block text-xs font-semibold text-[#3E2723]    mb-1">
                  Product Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Vanilla Celebration Cake"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl border border-[#C9A227]/30 text-sm text-[#3E2723] focus:outline-none focus:ring-2 focus:ring-[#C9A227]"
                />
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-semibold text-[#3E2723]    mb-1">
                  Description *
                </label>
                <textarea
                  rows={3}
                  required
                  placeholder="Ingredients, cake size, flavor details..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl border border-[#C9A227]/30 text-sm text-[#3E2723] focus:outline-none focus:ring-2 focus:ring-[#C9A227]"
                />
              </div>

              {/* Price & Category in 2 Columns */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#3E2723]    mb-1">
                    Price in Naira (₦) *
                  </label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: Number(e.target.value) })}
                    className="w-full px-3.5 py-2 rounded-xl border border-[#C9A227]/30 text-sm text-[#3E2723] font-bold focus:outline-none focus:ring-2 focus:ring-[#C9A227]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#3E2723]    mb-1">
                    Category *
                  </label>
                  <select
                    value={formData.categoryId}
                    onChange={(e) => setFormData({ ...formData, categoryId: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl border border-[#C9A227]/30 text-sm text-[#3E2723] focus:outline-none focus:ring-2 focus:ring-[#C9A227]"
                  >
                    {categories.map((c) => (
                      <option key={c._id} value={c._id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Image Upload & Preview */}
              <div>
                <label className="block text-xs font-semibold text-[#3E2723]    mb-1">
                  Product Image (Convex Storage / Max 5MB)
                </label>
                <div className="flex items-center gap-4">
                  <div className="relative w-20 h-20 rounded-xl overflow-hidden bg-[#FAF7F2] border border-[#C9A227]/30 shrink-0">
                    {imagePreview ? (
                      <Image
                        src={imagePreview}
                        alt="Preview"
                        fill
                        className="object-cover"
                        sizes="80px"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-xs text-[#5D4037]/60">
                        No image
                      </div>
                    )}
                  </div>

                  <div className="flex-1 space-y-2">
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileChange}
                      accept="image/jpeg,image/png,image/webp"
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isUploadingImage}
                      className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-[#FAF7F2] hover:bg-[#F4EFEA] border border-[#C9A227]/40 text-xs font-semibold text-[#3E2723] transition-colors"
                    >
                      <Upload className="w-3.5 h-3.5 text-[#C9A227]" />
                      <span>{isUploadingImage ? 'Uploading...' : 'Choose Image File'}</span>
                    </button>
                    {imagePreview && (
                      <button
                        type="button"
                        onClick={() => {
                          setImagePreview(null);
                          setFormData({ ...formData, imageUrl: '' });
                        }}
                        className="text-xs text-rose-600 hover:text-rose-800 ml-3"
                      >
                        Remove Image
                      </button>
                    )}
                    <p className="text-[11px] text-[#5D4037]/70">
                      JPG, PNG, or WebP up to 5MB. Previews instantly before saving.
                    </p>
                  </div>
                </div>
              </div>

              {/* Toggles: Available & Featured */}
              <div className="pt-2 flex items-center gap-6">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-[#3E2723]">
                  <input
                    type="checkbox"
                    checked={formData.isAvailable}
                    onChange={(e) => setFormData({ ...formData, isAvailable: e.target.checked })}
                    className="w-4 h-4 rounded text-[#3E2723] accent-[#3E2723]"
                  />
                  <span>Available for purchase / ordering</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-[#3E2723]">
                  <input
                    type="checkbox"
                    checked={formData.isFeatured}
                    onChange={(e) => setFormData({ ...formData, isFeatured: e.target.checked })}
                    className="w-4 h-4 rounded text-[#3E2723] accent-[#B8860B]"
                  />
                  <span>Feature on Homepage</span>
                </label>
              </div>

              {/* Submit Buttons */}
              <div className="mt-8 pt-4 border-t border-[#C9A227]/20 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsProductModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-stone-300 text-xs font-semibold text-[#5D4037] hover:bg-stone-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingProduct}
                  className="px-6 py-2.5 rounded-xl bg-[#3E2723] hover:bg-[#271612] text-white text-xs font-semibold border border-[#C9A227]/40 shadow-sm transition-all"
                >
                  {isSavingProduct ? 'Saving...' : editingProduct ? 'Save Changes' : 'Create Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {isDeleteModalOpen && productToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            onClick={() => setIsDeleteModalOpen(false)}
            className="fixed inset-0 bg-[#271612]/70 backdrop-blur-sm"
          />

          <div className="relative w-full max-w-md bg-white rounded-2xl border border-rose-300 shadow-2xl p-6 z-10 text-center">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto mb-4">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className=" text-xl font-bold text-[#3E2723]">Delete Product?</h3>
            <p className="mt-2 text-xs sm:text-sm text-[#5D4037]">
              Are you sure you want to permanently delete{' '}
              <strong className="text-[#3E2723]">&ldquo;{productToDelete.name}&rdquo;</strong>? This
              will also clean up its stored image file from storage.
            </p>

            <div className="mt-6 flex items-center justify-center gap-3">
              <button
                onClick={() => setIsDeleteModalOpen(false)}
                className="px-4 py-2 rounded-xl border border-stone-300 text-xs font-semibold text-[#5D4037] hover:bg-stone-50"
              >
                Cancel
              </button>
              <button
                onClick={confirmDeleteProduct}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold shadow-sm"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Categories Manager Modal */}
      {isCategoryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div
            onClick={() => setIsCategoryModalOpen(false)}
            className="fixed inset-0 bg-[#271612]/70 backdrop-blur-sm"
          />

          <div className="relative w-full max-w-lg bg-white rounded-2xl border border-[#C9A227]/40 shadow-2xl p-6 sm:p-8 z-10">
            <div className="flex items-center justify-between pb-4 border-b border-[#C9A227]/20">
              <h3 className=" text-xl font-bold text-[#3E2723]">Manage Menu Categories</h3>
              <button
                onClick={() => setIsCategoryModalOpen(false)}
                className="text-[#5D4037] hover:text-[#3E2723]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Add Category Form */}
            <div className="mt-6">
              <label className="block text-xs font-semibold text-[#3E2723]    mb-1.5">
                Add New Category
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="e.g. Wedding Cakes, Breads..."
                  value={newCategoryName}
                  onChange={(e) => setNewCategoryName(e.target.value)}
                  className="flex-1 px-3.5 py-2 rounded-xl border border-[#C9A227]/30 text-xs text-[#3E2723] focus:outline-none focus:ring-2 focus:ring-[#C9A227]"
                />
                <button
                  type="button"
                  onClick={async () => {
                    if (!newCategoryName.trim()) return;
                    await addCategory(newCategoryName);
                    setNewCategoryName('');
                  }}
                  className="px-4 py-2 rounded-xl bg-[#3E2723] text-white text-xs font-semibold hover:bg-[#271612]"
                >
                  Add
                </button>
              </div>
            </div>

            {/* Existing Categories List */}
            <div className="mt-6 pt-4 border-t border-[#C9A227]/15 space-y-2">
              <span className="text-xs font-semibold    text-[#5D4037] block mb-2">
                Existing Categories ({categories.length})
              </span>
              {categories.map((cat) => {
                const isEditing = editingCatId === cat._id;
                const countLinked = products.filter((p) => p.categoryId === cat._id).length;

                return (
                  <div
                    key={cat._id}
                    className="flex items-center justify-between p-3 rounded-xl bg-[#FAF7F2] border border-[#C9A227]/20 text-xs"
                  >
                    {isEditing ? (
                      <div className="flex items-center gap-2 flex-1 mr-2">
                        <input
                          type="text"
                          value={editingCatName}
                          onChange={(e) => setEditingCatName(e.target.value)}
                          className="flex-1 px-2.5 py-1 rounded border border-[#C9A227] text-xs text-[#3E2723]"
                        />
                        <button
                          onClick={async () => {
                            await updateCategory(cat._id, editingCatName);
                            setEditingCatId(null);
                          }}
                          className="p-1 rounded bg-emerald-600 text-white"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setEditingCatId(null)}
                          className="p-1 rounded bg-stone-300 text-stone-700"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <div>
                        <span className="font-semibold text-[#3E2723]">{cat.name}</span>
                        <span className="text-[11px] text-[#5D4037]/70 ml-2">
                          ({countLinked} product{countLinked === 1 ? '' : 's'})
                        </span>
                      </div>
                    )}

                    {!isEditing && (
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => {
                            setEditingCatId(cat._id);
                            setEditingCatName(cat.name);
                          }}
                          className="p-1 text-[#5D4037] hover:text-[#3E2723]"
                          title="Rename"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => deleteCategory(cat._id)}
                          className="p-1 text-rose-600 hover:text-rose-800"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="mt-8 pt-4 border-t border-[#C9A227]/20 flex justify-end">
              <button
                type="button"
                onClick={() => setIsCategoryModalOpen(false)}
                className="px-5 py-2 rounded-xl bg-[#3E2723] text-white text-xs font-semibold"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
